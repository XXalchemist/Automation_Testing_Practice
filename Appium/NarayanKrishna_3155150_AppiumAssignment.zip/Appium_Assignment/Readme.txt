----------------------------------------------
Appium Assignment

Submission Date : 14/01/2021  

Created by :-
Name : Narayan Krishna 
EmpId : 3155150
----------------------------------------------

----------------------------------------------
Application used : WorkIndia

----------------------------------------------

--- Instructions To Run Test ----------------- 

Open Run_Assignment.bat file

----------------------------------------------

------------------ Output Directory ---------

Extent Report : ./output/Extent_Report
Logs (Info, Error, All) : ./output/logs
Screenshot : ./output/screenshots/

----------------------------------------------

Configuration File : ./Resources/props/
Application (apk) : ./Resources/Application

**********************************************   