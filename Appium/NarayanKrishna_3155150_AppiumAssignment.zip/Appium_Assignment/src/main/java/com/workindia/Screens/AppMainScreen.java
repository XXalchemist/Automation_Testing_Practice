package com.workindia.Screens;

import java.util.ArrayList;
import java.util.List;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

import com.workindia.Utils.CommonUtils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindAll;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class AppMainScreen {


	public AppiumDriver<MobileElement> driver;

	public AppMainScreen(AppiumDriver<MobileElement> driver) {

		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	// Elements
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = \"WorkIndia\"]")
	private MobileElement appMainScreenHeading;

	@AndroidFindBy(id = "et_inputSearch")
	private MobileElement searchField;

	@AndroidFindBy(xpath = "//*[@text = \"Car Cleaner\"]")
	private MobileElement searchedElementHeading;

	// Actions
	public String getHeadingOfAppMainScreen() {

		String heading = appMainScreenHeading.getAttribute("text");

		// implicit wait		
		CommonUtils.implicitWait();

		return heading;

	}

	public void searchJob(String jobName) {

		searchField.sendKeys(jobName);

		// implicit wait		
		CommonUtils.implicitWait();

	}

	public String getTextForSearchedElement() {

		// getting first element from listener
		String headingSearchElement = searchedElementHeading.getAttribute("text").toLowerCase();

		// implicit wait		
		CommonUtils.implicitWait();

		return headingSearchElement;

	}
}
