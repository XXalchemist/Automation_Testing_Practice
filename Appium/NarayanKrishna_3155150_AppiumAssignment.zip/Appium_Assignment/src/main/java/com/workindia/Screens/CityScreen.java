package com.workindia.Screens;

import org.openqa.selenium.support.PageFactory;

import com.workindia.Utils.CommonUtils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.offset.ElementOption;

public class CityScreen {

	public static AppiumDriver<MobileElement> driver;

	public CityScreen(AppiumDriver<MobileElement> driver) {

		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	// Elements
	@AndroidFindBy(id = "tv_city")
	private MobileElement cityScreenTitle;

	@AndroidFindBy(id = "rb_pune")
	private MobileElement puneSelectedField;

	@AndroidFindBy(id = "act_auto_complete")
	private MobileElement aboutCityField;

	@AndroidFindBy(id = "btn_done")
	private MobileElement submitButtonOnCityScreen;


	// Actions
	public String getCityScreenTitle() {

		String titleName = cityScreenTitle.getAttribute("text");

		// implicit wait		
		CommonUtils.implicitWait();

		return titleName;
	}

	public void selectPuneCity() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (puneSelectedField)))
		.perform ();

		// implicit wait		
		CommonUtils.implicitWait();

	}

	public void enterAboutCity(String about) {

		aboutCityField.setValue(about);

		// implicit wait		
		CommonUtils.implicitWait();

	}

	public void tapOnSubmit() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (submitButtonOnCityScreen)))
		.perform ();



		// implicit wait		
		CommonUtils.implicitWait();

	}
}
