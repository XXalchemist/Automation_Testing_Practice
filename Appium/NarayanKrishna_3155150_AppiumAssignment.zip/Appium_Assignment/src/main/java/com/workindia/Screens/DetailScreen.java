package com.workindia.Screens;

import org.openqa.selenium.support.PageFactory;

import com.workindia.Utils.CommonUtils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.offset.ElementOption;

public class DetailScreen {

	public static AppiumDriver<MobileElement> driver;

	public DetailScreen(AppiumDriver<MobileElement> driver) {

		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	// Elements
	@AndroidFindBy(id = "tv_profile_heading")
	private MobileElement detailScreenHeading;

	@AndroidFindBy(id = "rg_male")
	private MobileElement genderMaleButton;

	@AndroidFindBy(id = "rb_graduate")
	private MobileElement qualificationButton;

	@AndroidFindBy(id = "cb_english")
	private MobileElement schoolMediumButton;

	@AndroidFindBy(id = "rg_eng_level_2")
	private MobileElement englishLevelButton;

	@AndroidFindBy(id = "cb_fresher")
	private MobileElement experienceButton;

	@AndroidFindBy(id = "et_age")
	private MobileElement ageField;

	// See this later on
	@AndroidFindBy(xpath =  "//android.widget.TextView[@index = 8]")
	private MobileElement selectAge;

	@AndroidFindBy(xpath = "//*[@text = \"Driver\"]")
	private MobileElement selectInterestedTopic;

	@AndroidFindBy(id = "btn_done")
	private MobileElement submitButtonOnDetailScreen;

	// Actions
	public String getDetailScreenTitle() {

		String title = detailScreenHeading.getAttribute("text");

		// implicit wait		
		CommonUtils.implicitWait();

		return title;
	}

	public void tapOnGenderMaleButton() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (genderMaleButton)))
		.perform ();
		// implicit wait		
		CommonUtils.implicitWait();

	}

	public void tapOnQualificationButton() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (qualificationButton)))
		.perform ();

		// implicit wait		
		CommonUtils.implicitWait();

	}

	public void tapOnSchoolMediumButton() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (schoolMediumButton)))
		.perform ();

		// implicit wait		
		CommonUtils.implicitWait();

	}

	public void tapOnEnglishButton() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (englishLevelButton)))
		.perform ();

		// implicit wait		
		CommonUtils.implicitWait();

	}

	public void tapOnExperienceButton() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (experienceButton)))
		.perform ();

		// implicit wait		
		CommonUtils.implicitWait();

	}

	public void tapOnAgeButton() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (ageField)))
		.perform ();

		// implicit wait		
		CommonUtils.implicitWait();

	}

	public void selectAge() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (selectAge)))
		.perform ();
		// implicit wait		
		CommonUtils.implicitWait();

	}


	public void selectInterestedTopic() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (selectInterestedTopic)))
		.perform ();

		// implicit wait		
		CommonUtils.implicitWait();

	}

	public void tapOnSubmitButtonOnDetailScreen() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (submitButtonOnDetailScreen)))
		.perform ();

		// implicit wait		
		CommonUtils.implicitWait();

	}

}
