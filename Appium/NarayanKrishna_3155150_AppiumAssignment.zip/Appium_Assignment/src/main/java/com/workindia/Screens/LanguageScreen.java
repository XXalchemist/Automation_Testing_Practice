package com.workindia.Screens;

import org.openqa.selenium.support.PageFactory;

import com.workindia.Utils.CommonUtils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.offset.ElementOption;

public class LanguageScreen {


	public static AppiumDriver<MobileElement> driver;

	public LanguageScreen(AppiumDriver<MobileElement> driver) {

		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	// Elements

	@AndroidFindBy(id = "btn_english")
	private MobileElement englishButton;

	@AndroidFindBy(id = "btn_hindi")
	private MobileElement hindiButton;

	// Actions

	public boolean englishButtonIsClickable() {

		return englishButton.isDisplayed();
	}

	public void tapOnEnglishButton() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (englishButton)))
		.perform ();

		// implicit wait		
		CommonUtils.implicitWait();

	}

	public void tapOnHindiButtonButton() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (hindiButton)))
		.perform ();

		// implicit wait		
		CommonUtils.implicitWait();

	}


}
