package com.workindia.Screens;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

import com.workindia.Utils.CommonUtils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.offset.ElementOption;

public class NavigationMenu {
	
	
	public static AppiumDriver<MobileElement> driver;
	
	public NavigationMenu(AppiumDriver<MobileElement> driver) {

		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	// Elements
	
	@AndroidFindBy(id = "navigation_home")
	private MobileElement jobIcon;
	
	@AndroidFindBy(id = "navigation_applied")
	private MobileElement appliedJobs;

	@AndroidFindBy(id = "navigation_wall")
	private MobileElement tipIcon;
	
	@AndroidFindBy(id = "navigation_ham_menu")
	private MobileElement profileIcon;
	
	@AndroidFindBy(id = "navigation_share_win")
	private MobileElement shareAndWinIcon;
	
	@AndroidFindBy(xpath = "//*[@text = \"Tell Us Your Requirement\"]")
	public MobileElement footerOnProfileMenu;
	
	// Actions
	public boolean elementsIsClickableOnNavMenu() {
		
		String jobIconCond = jobIcon.getAttribute("clickable");
		String appliedJobsIconCond = appliedJobs.getAttribute("clickable");
		String tipIconIconCond = tipIcon.getAttribute("clickable");
		String profileIconCond = profileIcon.getAttribute("clickable");
		String shareAndWinIconCond = shareAndWinIcon.getAttribute("clickable");
		
		boolean clickableCondition = jobIconCond.equals("true")&& 
									 appliedJobsIconCond.equals("true")&&
									 tipIconIconCond.equals("true")&&
									 profileIconCond.equals("true")&&
									 shareAndWinIconCond.equals("true");
		return  clickableCondition;
	}
	
	public void tapOnProfileIcon() {
		
		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (profileIcon)))
		.perform ();
		

		// implicit wait		
				CommonUtils.implicitWait();
				
	}
	
	public void swipeUpTillFooterOfProfileMenu(int maxSwipes) {
		
		String errorMessage = "Element not found....";
		CommonUtils.swiUPTillFindElement(By.xpath( "//*[@text = \"Tell Us Your Requirement\"]"), errorMessage, maxSwipes);
	}
}
