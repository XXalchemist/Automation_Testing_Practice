package com.workindia.Screens;

import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.offset.ElementOption;

import com.workindia.Utils.CommonUtils;

public class RegisterScreen {

	public static AppiumDriver<MobileElement> driver;

	public RegisterScreen(AppiumDriver<MobileElement> driver) {

		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	// Creating Mobile Elements

	@AndroidFindBy(xpath = "//*[@text = 'Job Search']")
	private MobileElement registerScreenTitle;

	@AndroidFindBy(id = "et_name")
	private MobileElement fullnameField;

	@AndroidFindBy(id = "et_number")
	private MobileElement mobileNumberField;

	@AndroidFindBy(id = "btn_submit")
	private MobileElement submitButtonOnRegisterScreen;

	@AndroidFindBy(id = "tv_referral_code")
	private MobileElement refCode;

	@AndroidFindBy(id = "et_referral_code")
	private MobileElement refCodeField;

	@AndroidFindBy(id = "tv_message")
	private MobileElement refCodeMessage;

	@AndroidFindBy(id = "android:id/button1")
	private MobileElement applyButton;

	// Actions
	public String getRegisterScreenTitle() {

		String title = registerScreenTitle.getAttribute("text");
		return title;
	}

	public void enterFullname(String fullname) {

		fullnameField.setValue(fullname);

		// implicit wait		
		CommonUtils.implicitWait();

	}

	public void enterMobileNumber(String mobileNumber) {

		mobileNumberField.setValue(mobileNumber);

		// implicit wait		
		CommonUtils.implicitWait();

	}

	public void tapOnSubmit() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (submitButtonOnRegisterScreen)))
		.perform ();


		// implicit wait		
		CommonUtils.implicitWait();

	}

	public void tapOnRefCode() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (refCode)))
		.perform ();

		// implicit wait		
		CommonUtils.implicitWait();


	}

	public void enterRefCode(String code) {

		refCodeField.setValue(code);

		// implicit wait		
		CommonUtils.implicitWait();


	}

	public String getRefCodeMessage() {

		String text = refCodeMessage.getAttribute("text");

		// for check remove later
		System.out.println("Message is "+refCodeMessage.getAttribute("text"));

		return text;
	}

	public void tapOnApply() {

		// why this regular id is not working ?
		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (applyButton)))
		.perform ();

		// implicit wait		
		CommonUtils.implicitWait();

	}
}
