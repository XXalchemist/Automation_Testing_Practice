package com.workindia.Screens;

import org.openqa.selenium.support.PageFactory;

import com.workindia.Utils.CommonUtils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.offset.ElementOption;

public class SkillScreen {

	public static AppiumDriver<MobileElement> driver;

	public SkillScreen(AppiumDriver<MobileElement> driver) {

		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	// Elements

	@AndroidFindBy(id = "tv_profile_heading")
	private MobileElement skillScreenHeading;

	@AndroidFindBy(id = "et_skill_1")
	private MobileElement skillButton; 

	@AndroidFindBy(xpath = "//*[@text = \"Other\"]")
	private MobileElement otherButton;

	@AndroidFindBy(id = "android:id/button1")
	private MobileElement applyButton;

	@AndroidFindBy(id = "et_course")
	private MobileElement courseSelection;

	@AndroidFindBy(xpath = "//*[@text = \"BA\"]")
	private MobileElement courseBA;


	@AndroidFindBy(id = "btn_done")
	private MobileElement submitButtonOnSkillScreen;

	// Actions

	public String getSkillScreenHeading() {

		String title = skillScreenHeading.getAttribute("text");
		return title;

	}

	public void tapOnSkillButton() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (skillButton)))
		.perform ();

		// implicit wait
		CommonUtils.implicitWait();
	}

	public void tapOnOtherButton() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (otherButton)))
		.perform ();

		// implicit wait
		CommonUtils.implicitWait();
	}

	public void tapOnApply() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (applyButton)))
		.perform ();

		// implicit wait
		CommonUtils.implicitWait();
	}

	public void selectCourseOnSkillScreen() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (courseSelection)))
		.perform ();

		// implicit wait
		CommonUtils.implicitWait();

		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (courseBA)))
		.perform ();

		// implicit wait
		CommonUtils.implicitWait();
	}

	public void tapOnSubmitButtonOnSkillScreen() {

		AndroidTouchAction touch = new AndroidTouchAction (driver);
		touch.tap (TapOptions.tapOptions ()
				.withElement (ElementOption.element (submitButtonOnSkillScreen)))
		.perform ();

		// implicit wait
		CommonUtils.implicitWait();
	}
}
