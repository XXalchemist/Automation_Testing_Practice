package com.workindia.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;



public class BaseTest {

	// appium driver
	public static AppiumDriver<MobileElement> driver;

	// File Location Stored in string for proper uses
	private static String configurationLocation = "./resources/props/configuration.properties";
	
	//private static String testDataLocation = "./resources/props/testData.properties";


	// Implementing log4j for all
	public final static Logger logger = LogManager.getLogger(BaseTest.class);


	// Implementing prop file reader
	public static Properties prop = new Properties();

	// File location change it to dynamic
	private static File file = new File(configurationLocation);

	// FIS needed for prop
	private static FileInputStream fis = null;

	// Static block - start the assignment as soon as class in instantiated
	static {

		// Exception Handling for FIS
		try {

			fis = new FileInputStream(file);
		}catch(FileNotFoundException e){

			System.out.println(e.getMessage());
		}

		// Exception Handling for Prop
		try {

			prop.load(fis);
		}catch(IOException e) {

			System.out.println(e.getMessage());
		}

	}


	// Creating driver setup and teardown method
	public static void setUp() throws MalformedURLException {

		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, prop.getProperty("deviceName"));
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, prop.getProperty("platformName"));
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, prop.getProperty("platformVersion"));

		// App package name you can get from apk info app
		capabilities.setCapability("appPackage", prop.getProperty("appPackage"));
		capabilities.setCapability("app", prop.getProperty("app"));

		driver = new AndroidDriver<MobileElement>(new URL(prop.getProperty("url")), capabilities);

		// Show All information to logger
		logger.info("--------------------------SetUp Completed--------------------");
		logger.info("DEVICE_NAME : "+prop.getProperty("deviceName"));
		logger.info("PLATFORM_NAME : "+prop.getProperty("platformName"));
		logger.info("PLATFORM_VERSION : "+prop.getProperty("platformVersion"));
		logger.info("APP_NAME : "+prop.getProperty("app"));
		logger.info("-------------------------------------------------------------");

	}

	public static void closeTheDriver() {

		// close the application
		driver.quit();
		logger.info("---- driver closed ----");
	}
	
	public static void removeApp() {
		
		//Remove the app - not working
		driver.removeApp(prop.getProperty("appPackage"));
		logger.info("App : "+prop.getProperty("appPackage")+" was uninstalled from device");
	}

}
