package com.workindia.Utils;


import org.apache.log4j.Logger;

import io.appium.java_client.service.local.AppiumDriverLocalService;

public class Server {

	public static AppiumDriverLocalService service;


	// starting and closing the server
	public static void startAppium() {
		service = AppiumDriverLocalService.buildDefaultService();
		service.start();
	}

	public static void stopAppium() {
		service.stop();

	}

}
