package com.workindia.StepDefs;

import org.testng.Assert;

import com.workindia.Screens.AppMainScreen;
import com.workindia.Utils.BaseTest;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AppMainScreenTest extends BaseTest {
	
	AppMainScreen appMainScreen = null;
	
	@When("^I searched for (?:valid|invalid) '(.*)'$")
	public void i_searched_for_valid_Car_Cleaner(String jobName) {
		
		appMainScreen = new AppMainScreen(driver);
		appMainScreen.searchJob(jobName);
		
		// set jobName for prop file
		logger.info("Job: "+jobName+" was entered in searh box");
	}

	@Then("^I (?:did|did not) get the result$")
	public void i_get_the_result() {
	  
		
		appMainScreen = new AppMainScreen(driver);
		String expectedJobName = prop.getProperty("expectedJobName"); // take it with prop file
		String actualJobName = "";
		
		try {
		actualJobName = appMainScreen.getTextForSearchedElement();
		
		Assert.assertEquals(actualJobName, expectedJobName);
		logger.info("actualJobName : "+actualJobName+"expectedJobName : "+expectedJobName+"matched");
		}
		catch(Exception e)
		{
			logger.info("Exception occured: "+e.getMessage()+"\nEmpty Element....\nAssertion Passed...");
		}
		
	}

}
