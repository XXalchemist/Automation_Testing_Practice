package com.workindia.StepDefs;

import org.testng.Assert;

import com.workindia.Screens.CityScreen;
import com.workindia.Screens.DetailScreen;
import com.workindia.Utils.BaseTest;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CityScreenTest extends BaseTest{

	CityScreen cityScreen = null;
	DetailScreen detailScreen = null;
	
	@When("^I select my city '(.*)'$")
	public void i_select_my_city(String cityName) {
	    
		cityScreen = new CityScreen(driver);
		cityScreen.selectPuneCity();
		
		logger.info("City : "+cityName+" was selected");
	}

	@When("^I add about my city '(.*)'$")
	public void i_add_about_my_city(String about) {
	    
		cityScreen = new CityScreen(driver);
		cityScreen.enterAboutCity(about);
		
		logger.info("Description : "+about+" was added");
	}

	@When("^I tap on submit button$")
	public void i_tap_on_submit_button() {
	    
		cityScreen = new CityScreen(driver);
		cityScreen.tapOnSubmit();
		
		logger.info("Submit button on City screen was tapped");
	}

	@Then("^Detail screen was displayed$")
	public void detail_screen_was_displayed() {
	    
		detailScreen = new DetailScreen(driver);
		String detailScreenHeading = detailScreen.getDetailScreenTitle();
		String expectedString = "Please Fill All Details";
		
		Assert.assertEquals(detailScreenHeading, expectedString);
		logger.info("Assertion was done, "+" Actual : "+detailScreenHeading+" ,Expected : "+expectedString);
	}

}
