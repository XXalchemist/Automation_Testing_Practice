package com.workindia.StepDefs;

import org.testng.Assert;

import com.workindia.Screens.DetailScreen;
import com.workindia.Screens.SkillScreen;
import com.workindia.Utils.BaseTest;
import com.workindia.Utils.CommonUtils;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DetailScreenTest extends BaseTest {

	DetailScreen detailScreen = null;
	SkillScreen skillScreen = null;
	
	@When("^I tap on male of gender button$")
	public void i_tap_on_male_of_gender_button() {
	   
		detailScreen = new DetailScreen(driver);
		
		detailScreen.tapOnGenderMaleButton();
		logger.info("Male Gender Button was tapped");
	}

	@When("^I tap on graduate of qualification$")
	public void i_tap_on_graduate_of_qualification() {
	    
		detailScreen = new DetailScreen(driver);
		detailScreen.tapOnQualificationButton();
		
		logger.info("Graduate qualification was tapped");
	}

	@When("^I tap on english of school medium$")
	public void i_tap_on_english_of_school_medium() {
	    
		detailScreen = new DetailScreen(driver);
		detailScreen.tapOnSchoolMediumButton();
		
		logger.info("School Medium was tapped");
		
	}

	@When("^I tap on normal english of english level$")
	public void i_tap_on_normal_english_of_english_level() {
		
		detailScreen = new DetailScreen(driver);
		detailScreen.tapOnEnglishButton();
		
		logger.info("English Level was tapped");
	}

	@When("^I tap on freshers of experience level$")
	public void i_tap_on_freshers_of_experience_level() {
	    
		detailScreen = new DetailScreen(driver);
		detailScreen.tapOnExperienceButton();
		
		logger.info("Experience Level : Fresher was selected");
	}

	@When("^I swipe up$")
	public void i_swipe_up() {
	    
		CommonUtils.swipeScreen(CommonUtils.Direction.UP);
		
		logger.info("Swipe up operation was done");
	}

	@When("^I tap on age button$")
	public void i_tap_on_age_button() {
	    
		detailScreen = new DetailScreen(driver);
		detailScreen.tapOnAgeButton();
		
		logger.info("Age button was tapped");
	}

	@When("^I select my age$")
	public void i_select_my_age() {
	    
		detailScreen = new DetailScreen(driver);
		detailScreen.selectAge();
		
		logger.info("Age was selected");
	}

	@When("^I selected Driver of interested topics$")
	public void i_selected_Driver_of_interested_topics(){
	    
		detailScreen = new DetailScreen(driver);
		detailScreen.selectInterestedTopic();
		
		logger.info("Interested topic was tapped");
	}

	@When("^I click on Submit button on detail screen$")
	public void i_click_on_Submit_button_on_detail_screen() {
	    
		detailScreen = new DetailScreen(driver);
		detailScreen.tapOnSubmitButtonOnDetailScreen();
		
		logger.info("Submit button on Detail Screen was tapped");
	}

	@Then("^Skill screen pops up$")
	public void skill_screen_pops_up() {
	    
		skillScreen = new SkillScreen(driver);
		String expectedHeading = prop.getProperty("expectedSkillScreenHeading");
		
		boolean assertCondition = skillScreen.getSkillScreenHeading().contains(expectedHeading);
		
		Assert.assertTrue(assertCondition);
		
		logger.info("Assertion for checking heading of skill screen");
	}

}
