package com.workindia.StepDefs;

import org.testng.Assert;

import com.workindia.Screens.AppMainScreen;
import com.workindia.Screens.LanguageScreen;
import com.workindia.Utils.BaseTest;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LanguageScreenTest extends BaseTest{
	
	LanguageScreen languageScreen = null;
	AppMainScreen appMainScreen = null;
	
	@When("^I select english as language$")
	public void i_select_english_as_language() {
	   
		languageScreen = new LanguageScreen(driver);
		languageScreen.tapOnEnglishButton();
		
		logger.info("English Language was selected");
	}

	@When("^I click on submit button on language screen$")
	public void i_click_on_submit_button_on_language_screen() {
	    
		languageScreen = new LanguageScreen(driver);
		//
	}

	@Then("^App main screen pops up$")
	public void app_main_screen_pops_up() {
	 
		appMainScreen = new AppMainScreen(driver);
		String expectedHeading = appMainScreen.getHeadingOfAppMainScreen();
		
		Assert.assertTrue(expectedHeading.contains("WorkIndia"));
		
		logger.info("Assertion was done on heading of app main screen");
		
	}

}
