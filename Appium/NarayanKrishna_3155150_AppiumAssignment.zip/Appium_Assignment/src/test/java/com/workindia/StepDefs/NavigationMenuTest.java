package com.workindia.StepDefs;

import org.testng.Assert;

import com.workindia.Screens.NavigationMenu;
import com.workindia.Utils.BaseTest;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class NavigationMenuTest extends BaseTest {

	NavigationMenu navigationMenu = null;


	@Then("^I see all the icons of navigation menu$")
	public void i_see_all_the_icons_of_navigation_menu() {

		navigationMenu = new NavigationMenu(driver);

		Assert.assertTrue(navigationMenu.elementsIsClickableOnNavMenu());

		logger.info("Checked all elements on navigation menu can be clicked by the user");
	}

	@When("^I tap on profile icon$")
	public void i_tap_on_profile_icon(){

		navigationMenu = new NavigationMenu(driver);

		navigationMenu.tapOnProfileIcon();

		logger.info("Profile icon was tapped");
	}

	@Then("^I swipe up '(\\d+)' to the footer of the profile menu$")
	public void i_swipe_up_to_the_footer_of_the_profile_menu(int maxSwipes) {

		navigationMenu = new NavigationMenu(driver);

		try {
			navigationMenu.swipeUpTillFooterOfProfileMenu(maxSwipes);

			logger.info("Element found within max swipe : "+maxSwipes);
		}
		catch(Exception e) {

			logger.error("Exception Occured: "+e.getMessage());			
		}
		finally {

			logger.info("Elements was not found in "+maxSwipes+" max swipe.");
		}
	}

}
