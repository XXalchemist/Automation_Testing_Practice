package com.workindia.StepDefs;

import java.net.MalformedURLException;

import org.testng.Assert;

import com.workindia.Screens.CityScreen;
import com.workindia.Screens.RegisterScreen;
import com.workindia.Utils.BaseTest;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegisterScreenTest extends BaseTest {

	RegisterScreen registerScreen = null;
	CityScreen cityScreen = null;

	@Given("^I start the application$")
	public void i_start_the_application() throws MalformedURLException {

		// launch the application
		setUp();
		logger.info("---- App Started ----");
	}

	@When("^I entered the (?:valid|invalid) '(.*)' and (?:valid|invalid) '(.*)'$")
	public void i_entered_the_fullname_and_mobileNumber(String fullname, String mobileNumber) {

		registerScreen = new RegisterScreen(driver);

		registerScreen.enterFullname(fullname);
		logger.info("Fullname : "+fullname+ " was entered");

		registerScreen.enterMobileNumber(mobileNumber);
		logger.info("Mobile Number : "+mobileNumber+" was entered");
	}

	@When("^Tap on submit button$")
	public void tap_on_submit_button() {

		registerScreen = new RegisterScreen(driver);
		registerScreen.tapOnSubmit();
		logger.info("Submit button on register screen was clicked");
	}

	@Then("^City screen Pops up$")
	public void city_screen_Pops_up() {

		cityScreen = new CityScreen(driver);
		registerScreen = new RegisterScreen(driver);

		logger.info("Screen title was fetched ");
		String screenTitle = cityScreen.getCityScreenTitle();

		Assert.assertTrue(screenTitle.contains("Choose Your City"));
		logger.info("Assertion was done for screenTitle");
	}

	@Then("^City Screen not Pops up$")
	public void city_Screen_not_Pops_up() {

		registerScreen = new RegisterScreen(driver);
		String actualTitle = registerScreen.getRegisterScreenTitle();
		String expectedTitle = "Job Search";

		Assert.assertEquals(actualTitle, expectedTitle);
		logger.info("Assertion was done for title text ,"+"Actual : "+actualTitle+" Expected : "+expectedTitle);
	}

	@When("^I tap on refer link$")
	public void i_tap_on_refer_link() {

		registerScreen = new RegisterScreen(driver);
		registerScreen.tapOnRefCode();
		logger.info("Ref Code Link was tapped");
	}

	@When("^I entered the '(.*)'$")
	public void i_entered_the_code(String code) {

		registerScreen = new RegisterScreen(driver);
		registerScreen.enterRefCode(code);
		logger.info("Referral Code : "+ code +" was entered");
	}

	@Then("^I get the message Not a valid code$")
	public void i_get_the_message_Not_a_valid_code() {

		registerScreen = new RegisterScreen(driver);
		String actualText = registerScreen.getRefCodeMessage();
		String expectedText = prop.getProperty("expectedRefTestResult");

		logger.info("Text : "+ actualText +" was displayed");

		Assert.assertEquals(actualText, expectedText);
		logger.info("Assertion is done "+"Actual : "+actualText +" Expected : "+expectedText);
	}

	@When("^I tap on Apply button$")
	public void i_tap_on_apply_button() {

		registerScreen = new RegisterScreen(driver);
		registerScreen.tapOnApply();
		logger.info("---- Apply button was tapped ----");
	}

}
