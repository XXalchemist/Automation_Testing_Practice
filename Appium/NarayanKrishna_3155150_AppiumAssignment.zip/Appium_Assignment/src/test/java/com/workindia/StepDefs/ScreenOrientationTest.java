package com.workindia.StepDefs;

import org.testng.Assert;

import com.workindia.Utils.BaseTest;
import com.workindia.Utils.CommonUtils;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ScreenOrientationTest extends BaseTest{

	
	@When("^I turn on PORTRAIT mode$")
	public void i_turn_on_PORTRAIT_mode() {
		
		CommonUtils.rotateScreenPortrait();
	}
	
	@When("^I turn on LANDSCAPE mode$")
	public void i_turn_on_LANDSCAPE_mode() {
	    
		CommonUtils.rotateScreenLandscape();
	}

	@Then("^App screen orientation will be PORTRAIT$")
	public void app_screen_orientation_will_be_PORTRAIT(){
		
		String currentOrientation = driver.getOrientation().toString();
		String expectedOrientation = "PORTRAIT";
		
		Assert.assertEquals(currentOrientation, expectedOrientation);
		
		logger.info("PORTRAIT screen orientation test was done");
	}
	
	@Then("^App screen orientation will be LANDSCAPE$")
	public void app_screen_orientation_will_be_LANDSCAPE(){
		
		String currentOrientation = driver.getOrientation().toString();
		String expectedOrientation = "LANDSCAPE";
		
		Assert.assertEquals(currentOrientation, expectedOrientation);
		
		// Reset screen orientation to Portrait
		CommonUtils.rotateScreenPortrait();
		
		logger.info("LANDSCAPE screen orientation test was done");
	}
}
