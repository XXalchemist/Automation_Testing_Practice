package com.workindia.StepDefs;


import org.testng.Assert;

import com.workindia.Screens.LanguageScreen;
import com.workindia.Screens.SkillScreen;
import com.workindia.Utils.BaseTest;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SkillScreenTest extends BaseTest {

	SkillScreen skillScreen = null;
	LanguageScreen languageScreen = null;

	@When("^I tap on select skill$")
	public void i_select_skills() {

		skillScreen = new SkillScreen(driver);
		skillScreen.tapOnSkillButton();

		logger.info("Skill Button was clicked");
	}

	@When("^I select course on skill screen$")
	public void i_select_course_on_skill_screen() throws Throwable {

		skillScreen = new SkillScreen(driver);
		skillScreen.selectCourseOnSkillScreen();

		logger.info("Course was selected");
	}

	@When("^I selected other skill$")
	public void i_selected_others() {

		skillScreen = new SkillScreen(driver);
		skillScreen.tapOnOtherButton();;

		logger.info("Others was tapped");
	}

	@When("^I tap on Apply button on skill screen$")
	public void i_tap_on_apply() {

		skillScreen = new SkillScreen(driver);
		skillScreen.tapOnApply();

		logger.info("Apply button was tapped");
	}

	@When("^I tap on submit button on skill screen$")
	public void i_tap_on_submit_button_on_skill_screen() {

		skillScreen = new SkillScreen(driver);
		skillScreen.tapOnSubmitButtonOnSkillScreen();

		logger.info("Submit button on Skill Screen was tapped");
	}

	@Then("^Language Screen pops up$")
	public void language_Screen_pops_up() {

		languageScreen = new LanguageScreen(driver);

		Assert.assertTrue(languageScreen.englishButtonIsClickable());

		logger.info("Assertion was done to check that button on language screen is displayed or not");
	}

}
