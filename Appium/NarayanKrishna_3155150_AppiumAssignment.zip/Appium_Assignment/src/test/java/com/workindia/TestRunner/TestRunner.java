package com.workindia.TestRunner;



import org.testng.annotations.AfterSuite;

import org.testng.annotations.BeforeSuite;

import com.workindia.Utils.BaseTest;
import com.workindia.Utils.Server;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
		features = "src/test/java/com/workindia/Features/", 
		glue = { "com/workindia/StepDefs/" }, // path of step definition
		plugin = { "com.cucumber.listener.ExtentCucumberFormatter:output/Extent_Test_report.html"}, 
		monochrome = false, // display console output in a readable format
		dryRun = false, // check all the steps have the definitions and will not execute
		strict = true  // check if any step is not defined in step definition file
		//tags = {}
		)



public class TestRunner extends AbstractTestNGCucumberTests {

	// Starting and Closing the server
	@BeforeSuite
	public void startServer() {

		Server.startAppium();
	}


	@AfterSuite()
	public void closeServer(){


		Server.stopAppium();
	}


}
