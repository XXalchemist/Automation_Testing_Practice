﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---- Sum of first 10 Natural Number ---");
            SumofFirstTenNaturalNumbers();

            Console.WriteLine("\n---- Sum of first n Natural Number ---");
            SumOfNNaturalNumbers();

            Console.WriteLine("\n---- Check if given number is palindrome or not ---");
            CheckNumberIsPalindrome();

            Console.ReadKey();
        }

        // Write a program to print sum of first 10 natural numbers
        static void SumofFirstTenNaturalNumbers()
        {
           int sumOfNaturalNumbers = 0;
            for(int number = 1; number<=10; number++)
            {
                sumOfNaturalNumbers += number;
            }
            Console.WriteLine($"Sum of first 10 natural number is {sumOfNaturalNumbers}");

        }

        // Write a program to print the sum of first n natural numbers
        static void SumOfNNaturalNumbers()
        {
            Console.Write("Enter the value of n : ");
            int n = Convert.ToInt32(Console.ReadLine());
            int sumOfNNaturalNumber = n * (n + 1) / 2;
            Console.WriteLine($"Sum of first {n} is {sumOfNNaturalNumber}");

        }

        // Write a program to find if a number is  a palindrome
        static void CheckNumberIsPalindrome()
        {
            int digit = 0;
            int reversedNumber = 0;
            Console.Write("Enter the number : ");
            int number = Convert.ToInt32(Console.ReadLine());
            int originalNumber = number;

            while (number != 0)
            {
                digit = number % 10;
                reversedNumber = (reversedNumber * 10) + digit;
                number = number / 10;
            }

            if (originalNumber == reversedNumber)
                Console.WriteLine($"Given number {originalNumber} is palindrome.");
            else
                Console.WriteLine($"Given number {originalNumber} is not palindrome.");

        }
    }
}
