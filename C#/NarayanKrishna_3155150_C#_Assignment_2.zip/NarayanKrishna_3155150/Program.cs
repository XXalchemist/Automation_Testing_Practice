﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("------***------***------***------");
            ReversedNumber();

            Console.WriteLine("------***------***------***------");
            ToCheckLeapYear();

            Console.WriteLine("------***------***------***------");
            ToDisplaySquaresAndCube();

            Console.WriteLine("------***------***------***------");
            ToDisplayDivision();

            Console.WriteLine("------***------***------***------");
            Console.ReadKey();
        }

        // Write a program to reverse number.
        static void ReversedNumber()
        {
            Console.WriteLine("To display reverse of the number.");
            Console.Write("Enter the number : ");
            int originalNumber = Convert.ToInt32(Console.ReadLine());
            int temp = originalNumber;
            int digit = 0;
            int reversedNumber = 0;

            while (temp != 0)
            {
                digit = temp % 10;
                reversedNumber = reversedNumber * 10 + digit;
                temp /= 10;
            }

            Console.WriteLine($"Reversed of given number {originalNumber} is {reversedNumber}.");
        }

        // Write a program to check if given year is a leap year or not.
        static void ToCheckLeapYear()
        {
            Console.WriteLine("To check the given year is leap year or not.");
            Console.Write("Enter the year : ");
            int year = int.Parse(Console.ReadLine());
            bool leap = false;

            if (year % 400 == 0)
            {
                if (year % 4 == 0 && year % 100 == 0)
                    leap = true;
                else
                    leap = false;
            }

            else
                leap = false;

            if (leap)
                Console.WriteLine($"Given year {year} is leap year.");
            else
                Console.WriteLine($"Given year {year} is not leap year.");
        }

        // Write a program to print square and cube table upto given number.
        static void ToDisplaySquaresAndCube()
        {
            Console.WriteLine("To display square and cubes upto N number");
            Console.Write("Enter the number : ");
            int number = int.Parse(Console.ReadLine());

            // Displaying squares
            Console.WriteLine($"Squares upto given number {number} :-");
            for(int i = 1; i <= number; i++)
            {
                Console.WriteLine($"{i} * {i} = {i * i}");
            }

            // Displaying cubes
            Console.WriteLine($"Cubes upto given number {number} :-");
            for(int i = 1; i <= number; i++)
            {
                Console.WriteLine($"{i} * {i} * {i} = {i * i * i}");
            }
        }

        /* Write a program to print division based on marks using switch case. Take total marks, obtained marks from user. Division categories are:
        * First(>=60%), Second(>=45% & <60%), Third(>=33% & <45%) & Fail(<33%).
        */
        static void ToDisplayDivision()
        {
            Console.WriteLine("To display division based on marks.");
            Console.Write("Enter total marks : ");
            int totalMarks = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter obtained marks : ");
            int obtainedMarks = Convert.ToInt32(Console.ReadLine());

            int percentage = (obtainedMarks * 100) / totalMarks;

            char condition = percentage >= 60 ? 'a' 
                : percentage < 60 && percentage >= 45 ? 'b' 
                : percentage < 45 && percentage >= 33 ? 'ç'
                : 'd' ; 

            switch (condition)
            {

                case ('a'):
                    Console.WriteLine($"First division with {percentage}% .");
                    break;

                case ('b'):
                    Console.WriteLine($"Second division with {percentage}% .");
                    break;

                case ('c'):
                    Console.WriteLine($"Third division with {percentage}% .");
                    break;

                case ('d'):
                    Console.WriteLine($"Fail with {percentage}% .");
                    break;

                default :
                    Console.WriteLine("Not valid Input.");
                    break;
            }
        }
       
    }
}
