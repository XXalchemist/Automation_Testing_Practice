﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--- Assignment-3 ---\n");

            Console.WriteLine("----   Calculator   ----\n");
            Calculator();
            Console.WriteLine("----   ***   ----\n");

            Console.WriteLine("----   To count the number of possible triangles   ----\n");
            ToCountTriangles();
            Console.WriteLine("----   ***   ----\n");

            Console.WriteLine("----   To find the number   ----\n");
            ToFindTheNumber();
            Console.WriteLine("----   ***   ----\n");

            Console.WriteLine("----   To display a pattern   ----\n");
            ToDisplayPattern();
            Console.WriteLine("----   ***   ----\n");

            Console.WriteLine("----   To display square of array   ----\n");
            ToDisplaySquareArray();
            Console.WriteLine("----   ***   ----\n");

            Console.ReadKey();

        }

        /* 1. Write a program for basic calculator.
        * Calculator has following options to perform any operation - add, subtract, Multiply, Division, modulus
        * Take above mentioned operation type from user and then accept two numbers from user.
        * Perform operation using switch case and display output with numbers and operation type.You need to display error message for any errors..
        */

        // Have to optimize code to enter number again ...
        private static bool Calculator()
        {
            char operation;
            int firstNumber = 0;
            int secondNumber = 0;
            int result = 0;



            Console.WriteLine("Enter the first number : ");
            bool firstNumberFlag = int.TryParse(Console.ReadLine(), out firstNumber);

            if (firstNumberFlag == false)
            {
                Console.WriteLine("Exception occured : Invalid Input !");
                return false;
            }

            Console.Write("::: Please Enter :::\n:> + To add\n:> - To Subtract\n:> * To Multiply\n:> / To Divide\n:> % To Modulus\n:>");
            bool operationFlag = char.TryParse(Console.ReadLine(), out operation);

            if(operationFlag == false)
            {
                Console.WriteLine("Exception occured : Invalid datatype of input !");
                return false;
            }

            Console.WriteLine("Enter the second number : ");
            bool secondNumberFlag = int.TryParse(Console.ReadLine(), out secondNumber);

            if (secondNumberFlag == false)
            {
                Console.WriteLine("Exception occured : Invalid Input !");
                return false;
            }
            switch (operation)
            {

                case '+':
                    result = firstNumber + secondNumber;
                    break;

                case '-':
                    result = firstNumber - secondNumber;
                    break;

                case '*':
                    result = firstNumber * secondNumber;
                    break;

                case '/':
                    try
                    {
                        result = firstNumber / secondNumber;
                        break;
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                        return false;
                    }

                case '%':
                    result = firstNumber % secondNumber;
                    break;


                default:
                    Console.WriteLine("Invalid Input : Invalid Operator, Please try again !");
                    break;
            }

            Console.WriteLine($"Result : {result}");
            return true;
        }

        /* 2. Write a program to find number of triangles which can be formed using any three numbers from an array of N size.
         * N is length/size of array.
         * Take all N values (which are dimensions for sides) from user.
         */

        private static bool ToCountTriangles()
        {
            int sizeOfArray = 0;
            int count = 0;

            Console.Write("Enter the size of array : ");

            bool sizeOfArrayFlag = int.TryParse(Console.ReadLine(), out sizeOfArray);
            if (sizeOfArrayFlag == false)
            {
                Console.WriteLine($"Exception Occured : Invalid input !");
                return false;
            }

            int[] sidesOfTriangles = new int[sizeOfArray];

            for (int i = 0; i < sizeOfArray; i++)
            {
                Console.WriteLine("Enter the side of triangle : ");
                bool sideFlag = int.TryParse(Console.ReadLine(), out sidesOfTriangles[i]);

                if (sideFlag == false)
                {
                    Console.WriteLine("Exception Occured: Invalid input !");
                    return false;
                }

            }

            Array.Sort(sidesOfTriangles);

            // Counting Possible Triangles : sum of two sides > third side
            // We need two iterators i...and j, k = i+2
            int k = 0;

            for (int i = 0; i < sizeOfArray - 2; i++)
            {
                k = i + 2;

                for (int j = i + 1; j < sizeOfArray; j++)
                {

                    while ((k < sizeOfArray) && (sidesOfTriangles[i] + sidesOfTriangles[j] > sidesOfTriangles[k]))
                    {
                        k++;
                    }
                    if (k > j)
                    {
                        count += k - j - 1;
                    }
                }
            }

            Console.WriteLine($"Possible number of triangles : {count}");
            return true;
        }

        /* 3. Given an integer N and an integer K, 
         * your task is to multiply the leftmost digit of the number to the number itself.
         * You have to repeat this process K times and print final outcome. 
         * For e.g. if N=7 & K=3 then: 
         *      7 * 7 = 49 
         *      49 * 4 = 196 
         *     196 * 1 = 196 
         */

        private static bool ToFindTheNumber()
        {
            int number = 0;
            int k = 0;
            int product = 0;

            try
            {
                Console.WriteLine("Enter the number : ");
                number = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter the value of k (iterations) : ");
                k = int.Parse(Console.ReadLine());
            }

            catch (Exception e)
            {
                Console.WriteLine($"Exception Occured : {e.Message}");
                return false;
            }

            int digit = 0;
            int temp = number;
            product = number;

            while (k != 0)
            {
                while (temp != 0)
                {
                    digit = temp % 10;
                    temp = temp / 10;
                }

                product = product * digit;

                temp = product;

                k--;
                Console.WriteLine($"---  Iteration {k+1}  -----\n {product}");

            }
            Console.WriteLine($"\n--- Result -----\n {product}");
            return true;

        }

        /* 4.  Print N dimension cross pattern with value as same as index (starting from 1). [N will always be odd number] 
         * e.g. if user gives number as 11 then pattern should be like- 
        1         11 
         2       10 
          3     9 
           4   8 
            5 7 
             6 
            5 7 
           4   8 
          3     9 
         2       10 
        1         11 
    */

        private static bool ToDisplayPattern()
        {
            int n = 0;
            int j = 0;
            Console.WriteLine("Enter the value of N (Odd Number only) : ");
            bool nFlag = int.TryParse(Console.ReadLine(), out n);

            if (nFlag == false)
            {
                Console.WriteLine("Exception occured : Invalid Input !");
                return false;
            }

            Console.WriteLine("Pattern is :> \n");
            if (n % 2 != 0)
            {

                for (int i = 0; i < n; i++)
                {
                    j = n - i - 1;
                    for (int k = 0; k < n; k++)
                    {

                        if (k == i || k == j)
                            Console.Write($"{k + 1}");
                        else
                            Console.Write(" ");
                    }
                    Console.WriteLine("");
                }
             
            }
            else 
                Console.WriteLine("Given number is not odd number.");
            return true;
        }

        /* 5. Write a program to print square array. 
         * You need to add user given integers to array until user doesn’t provide invalid number. 
         * Once you get invalid input, create and print new array having square values of base array numbers. 
         * Invalid input is any input x except -100 <= x <= 100. 
         * Anything except number will also be treated as invalid input. 
         * e.g. base array: [2, 5, 0, 12, 4]  => square array: [4, 25, 0, 144, 16] 
         */

        // Can also be solved using custom exception

        private static bool ToDisplaySquareArray()
        {
            int number = 0;

            List<int> numbers = new List<int>();


            while (true)
            {
                Console.WriteLine("Enter the number : ");

                try
                {
                    number = int.Parse(Console.ReadLine());

                    if (number > 100 || number < -100)
                    {
                        throw new Exception("Exception Occured : Invalid Number !");
                    }
                    else
                        numbers.Add(number);
                }
                catch (Exception e)
                {
                    Console.WriteLine($"{e.Message}");
                    SquareOfArray(numbers);
                    return true;

                }

            }
        }

        private static bool SquareOfArray(List<int> numbers)
        {

            for (int i = 0; i < numbers.Count; i++)
            {

                numbers[i] = numbers[i] * numbers[i];
            }

            if (numbers.Count == 0)
            {
                Console.WriteLine("Array is empty");
                return false;
            }
            else
            {
                Console.WriteLine("Square of given valid numbers are :- \n");
                foreach (int number in numbers)
                {
                    Console.WriteLine(number);
                }
            }
            return true;
        }


    }
}
