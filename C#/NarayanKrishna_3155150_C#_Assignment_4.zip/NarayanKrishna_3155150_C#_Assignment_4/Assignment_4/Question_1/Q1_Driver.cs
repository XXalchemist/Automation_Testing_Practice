﻿using Question_1.Records;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_1
{
    public class Q1_Driver
    {
        public enum Choices
        {
            ADD = 1,
            GETALL = 2,
            GET = 3,
            DELETE = 4
        }
        // Driver change later 
        public void Init_Q1 ()
        {
            bool stopFlag = false;
            int choice;
            string condition;

            Record record = new Record();

            while (!stopFlag)
            {
                try
                {
                    Console.WriteLine("\nUpto 10000 Employees data can be stored only !!");
                    Console.Write("\n--- Enter your choice ---\n 1. Add Record\t 2. Get all record\t 3. Get a record\t 4. Delete record\n ::> ");
                    choice = int.Parse(Console.ReadLine());

                    switch ((Choices) choice)
                    {

                        case Choices.ADD:
                            record.AddRecord();
                            break;

                        case Choices.GETALL:
                            record.GetAllRecord();
                            break;

                        case Choices.GET:
                            record.GetRecord();
                            break;

                        case Choices.DELETE:
                            record.DeleteRecord();
                            break;

                        default:
                            Console.WriteLine("Not a valid input !!!\n");
                            break;

                    }

                    Console.WriteLine("\nDo you want to continue -- yes or no ?");
                    condition = Console.ReadLine().ToLower();

                    if (condition.Equals("no"))
                        stopFlag = !stopFlag;
                    else if (condition.Equals("yes"))
                        continue;
                    else
                        Console.WriteLine("Not a valid input !! \n");
                }

                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.WriteLine("Try again !!!");

                }
            }
        }
    }
}
