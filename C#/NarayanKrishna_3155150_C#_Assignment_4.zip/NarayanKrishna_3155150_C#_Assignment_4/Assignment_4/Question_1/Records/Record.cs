﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_1.Records
{

    /* This class should contain :-
     * AddRecord method
     * GetRecord method
     * GetAllRecord method
     * DeleteRecord method
     * Creating unique id for user each time
     */
    class Record 
    {
        /* Each record should have id(random number),
         * list of salary amount for 3 months,
         * average salary, id and salary should be private.
         */
        private double averageSalary;
        private double [] listOfSalary; 
        private ArrayList record ;
        private int id;
        private string idStr;
        private string inputKey;
        private Random random = new Random();
        private Dictionary<string, ArrayList> recordData = new Dictionary<string, ArrayList>();

        // AddRecord should have id pass and also, requires list of salary for 3 months
        public void AddRecord()
        {
            id = GetUniqueId();
            string idStr = id.ToString();

            record = new ArrayList();
            listOfSalary = new double[3];
            Console.WriteLine($"\nID : {idStr}");

            // takes user input and add to the record
            for(int i = 0; i < 3; i++)
            {
                Console.Write($"Enter salary for {i + 1} month : ");
                listOfSalary[i] = double.Parse(Console.ReadLine());
            }
            record.Add(listOfSalary);
            
            // get average salary
            averageSalary = (listOfSalary[0]+listOfSalary[1]+listOfSalary[2]) / 3;
            record.Add(averageSalary);

            // We can add these items with the reference so that it can be accesed later through AllRecords class
           recordData.Add(idStr, record);
            
        }

        public void GetRecord()
        {
            listOfSalary = new double[3];
            Console.Write("\nEnter the id of record (show details) : ");
            inputKey = (Console.ReadLine());
            

            if (recordData.ContainsKey(inputKey))
            {
                listOfSalary = (double[]) recordData[inputKey][0];
                averageSalary = (double) recordData[inputKey][1];

                Console.WriteLine($"--- Id : {inputKey} --- Following Details ---\n");
                Console.WriteLine("Salary :-\n ");
                for(int i = 0; i < 3; i++)
                {
                    Console.Write($"Salary for month {i + 1} : {listOfSalary[i]}\n");
                }
                Console.WriteLine($"Average Salary : {averageSalary}\n");
            }
            else
                Console.WriteLine("Not valid id... Try Again !");
              
        }

        public void DeleteRecord()
        {
            Console.WriteLine("Enter the id of record (to be delete) : ");
            inputKey = Console.ReadLine();

            recordData.Remove(inputKey);

            Console.WriteLine($"\nDeleted id : {idStr} ...");
        }

        public void GetAllRecord()
        {
            listOfSalary = new double[3];

            if (recordData.Count() == 0)
                throw new Exception("Empty record !");

            // getting data 
            // Can also access data for different id and also check empty record
            foreach (var item in recordData)
            {
                Console.WriteLine($"\n-- Record for id {item.Key} ---\n");
                averageSalary = (double) item.Value[1];
                listOfSalary = (double[]) item.Value[0];

                // Showing data
            Console.WriteLine("Salaries for 3 months :-\n");
            for(int j = 0; j < 3; j++)
            {
                Console.WriteLine($"Salary for month {j + 1} : {listOfSalary[j]}");
            }

            Console.WriteLine($"\nAverage Salary : {averageSalary}");
            }
        }

        // Returning unique id for student (from range 1 - 10000) 
        public int GetUniqueId()
        {
            id = random.Next(1, 10000);
            
            // to check for unique id and throw exception if not so
            foreach (var emp in recordData)
            {
                if (emp.Key.Equals(id))
                    throw new Exception("Id already present !!");
            }
            return id;
        }
    }
}
