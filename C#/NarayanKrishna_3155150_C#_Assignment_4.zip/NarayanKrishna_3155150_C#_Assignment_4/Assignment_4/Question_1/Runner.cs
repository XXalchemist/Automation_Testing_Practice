﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_1
{
    class Runner
    {
        // Runner for Question 1
        public static void Main(string[] args)
        {
            Q1_Driver Q1 = new Q1_Driver();
            Q1.Init_Q1();
        }
    }
}
