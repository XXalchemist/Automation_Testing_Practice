﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Question_2.Records;

namespace Question_2
{
    public class Q2_Driver
    {
        public void Init_Q2()
        {
            bool stopFlag = false;
            int choice;
            string condition;

            Record record = new Record();
        

            while (!stopFlag)
            {
                try
                {

                    Console.Write("\nEnter your choice \n 0. To enter data\n 1. To get maximum patient count and respective day\n 2. To get minimum patient count and respective day\n 3. To get average of all patent count given \n 4. To get sum of all patent counts and total number of days\n::>  ");
                    choice = int.Parse(Console.ReadLine());

                    switch (choice)
                    {
                        case 0:
                            Console.WriteLine("Enter data :- ");
                            record.GetData();
                            break;

                        case 1:
                            record.GetMaximum();
                            break;

                        case 2:
                            record.GetMinimum();
                            break;

                        case 3:
                            record.GetAverage();
                            break;

                        case 4:
                            record.GetSum();
                            break;

                        default:
                            Console.WriteLine("\nNot valid input !!, Try again");
                            break;
                    }

                    Console.Write("\nDo you want to continue ?\nEnter Yes or No : ");
                    condition = Console.ReadLine().ToLower();

                    if (condition.Equals("no"))
                        stopFlag = true;
                    else if (condition.Equals("yes"))
                        continue;
                    else
                        Console.WriteLine("\nNot valid choice... Try again");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.WriteLine("Try again !!!");
                }
            }

        }
            
    }
}

