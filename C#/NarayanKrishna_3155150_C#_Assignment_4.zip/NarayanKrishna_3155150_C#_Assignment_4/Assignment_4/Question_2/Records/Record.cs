﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Change name of class later on
namespace Question_2.Records
{
    class Record
    {
        // Declare variables that can be used, and create constructor to take number of days as input.

        private int maxPatientCount;
        private int minPatientCount;
        private int avgPatientCount;
        private int sumPatientCount;
        private int numberOfDays;
        private int [] recordData;
        private int dayNumber;

        // Take input from user - number of days, patient count and store in record
        public void GetData()
        {
            Console.Write("\nEnter the number of days : ");
            numberOfDays = int.Parse(Console.ReadLine());

            // declare size of recordData
            recordData = new int[numberOfDays];

            // take patientCount for each day
            for(int i = 0; i < numberOfDays; i++)
            {
                Console.Write($"\nEnter the number of patient on day {i + 1} : ");
                recordData[i] = int.Parse(Console.ReadLine());
            }
        }

        // provides maximum patient count and respective day number
        public void GetMaximum()
        {
            int maxNumber = recordData[0];
            
            for(int i = 1; i < recordData.Count(); i++)
            {

                if (recordData[i] > maxNumber)
                    maxNumber = recordData[i];
            }

            maxPatientCount = maxNumber;

            // day of max patient count
            dayNumber = Array.IndexOf(recordData, maxPatientCount);

            Console.WriteLine($"\nMaximum patient count is {maxPatientCount} and it is found on day {dayNumber+1}.");
        }

        // provides minimum patient count and respective day number
        public void GetMinimum()
        {
            int minNumber = recordData[0];

            for(int i = 1; i < recordData.Count(); i++)
            {

                if (recordData[i] < minNumber)
                    minNumber = recordData[i];
            }

            minPatientCount = minNumber;
            dayNumber = Array.IndexOf(recordData, minNumber);

            Console.WriteLine($"\nMinimum patient count is {minPatientCount} and it is found on day {dayNumber + 1}.");
        }

        // provide average of count
        public void GetAverage()
        {
            sumPatientCount = Sum(recordData);

            avgPatientCount = sumPatientCount / recordData.Count();

            Console.WriteLine($"\nAverage patient count for the given data is {avgPatientCount}.");
            
        }

        // provide sum and total number of days
        public void GetSum()
        {

            sumPatientCount = Sum(recordData);

            Console.WriteLine($"\nTotal Patient : {sumPatientCount} and Total Days : {recordData.Count()}");
        }

        // To add up all values in array so it can be used again and agin
        public int Sum(int [] Data)
        {
            int sum = 0;
            foreach(int val in Data)
            {
                sum += val;
            }

            return sum;
        }

    }
}
