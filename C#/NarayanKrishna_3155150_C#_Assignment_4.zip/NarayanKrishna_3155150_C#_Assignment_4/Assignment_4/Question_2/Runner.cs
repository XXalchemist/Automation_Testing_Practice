﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_2
{
    // Runner for Q2
    class Runner
    {
        public static void Main(string[] args)
        {
            Q2_Driver Q2 = new Q2_Driver();
            Q2.Init_Q2();
        }
        
    }
}
