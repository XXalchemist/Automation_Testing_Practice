﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_3
{
    class Calculate
    {
        // data variables required

        private double principleAmount;
        private double simpleInterest;
        private double compoundInterest;
        private double rateOfInterest;
        private double totalAmount;
        private double time;
        public string yearOrMonth;

        // to take input
        public void GetPrincipleAmount()
        {
            Console.Write("\nEnter the principal amount : ");
            principleAmount = double.Parse(Console.ReadLine());

        }

        // get rate of interest
        public void GetRateOfInterest()
        {

            Console.Write("\nEnter the rate of interest : ");
            rateOfInterest = double.Parse(Console.ReadLine());
        }

        //  to perform SI
        public void GetSI()
        {

            simpleInterest = (principleAmount * rateOfInterest * time)/100;
            totalAmount = simpleInterest + principleAmount;

            Console.WriteLine($"\nSimple Interest : {simpleInterest} and Total Amount : {totalAmount}");
        }

        // to perform CI
        public void GetCI()
        {

            compoundInterest = principleAmount *(Math.Pow((1 + rateOfInterest / 100), time));
            totalAmount = compoundInterest + principleAmount;

            Console.WriteLine($"\nCompound Interest : {compoundInterest} and Total Amount : {totalAmount}");
        }

        // to take time - year or in months
        public void GetTime()
        {
            Console.Write("\nEnter Y for Year and M for month : ");
            yearOrMonth = Console.ReadLine().ToLower();

            Console.Write("\nEnter the time : ");
            time = double.Parse(Console.ReadLine());

            if (!yearOrMonth.Equals("y"))
                Console.WriteLine("\nNot valid input !! Try again");
            else if (yearOrMonth.Equals("m"))
                time = time / 12;
                         

        }

    }
}
