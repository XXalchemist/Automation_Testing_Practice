﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_3
{
   public class Q3_Driver
    {
       public void Init_Q3 ()
        {
            bool stopFlag = false;
            int choice;
            string condition;

            Calculate calculate = new Calculate();

            while (!stopFlag)
            {
                try
                {
                    Console.Write("\nEnter your choice : \n 1. To add data\n 2. To get Simple Interest \n 3. To get Compound interest\n ::> ");
                    choice = int.Parse(Console.ReadLine());

                    switch (choice)
                    {

                        case 1:
                            calculate.GetPrincipleAmount();
                            calculate.GetRateOfInterest();
                            calculate.GetTime();
                            break;

                        case 2:
                            calculate.GetSI();
                            break;

                        case 3:
                            calculate.GetCI();
                            break;

                        default:
                            Console.WriteLine("\nNot valid choice !! Try again");
                            break;
                    }

                    Console.Write("\nDo you want to continue ... Enter Y for yes and N for no : ");
                    condition = Console.ReadLine().ToLower();

                    if (condition.Equals("y"))
                        continue;
                    else if (condition.Equals("n"))
                        stopFlag = true;
                    else
                        Console.WriteLine("\nNot valid choice , try again !!");
                }

                catch(Exception e)
                {
                    Console.WriteLine($"\n{e.Message},... Try again !");
                }

            }

            
        }
    }
}
