﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_3
{
    // Runner for Q3
    class Runner
    {
        public static void Main(string[] args)
        {
            Q3_Driver Q3 = new Q3_Driver();
            Q3.Init_Q3();
        }
    }
}
