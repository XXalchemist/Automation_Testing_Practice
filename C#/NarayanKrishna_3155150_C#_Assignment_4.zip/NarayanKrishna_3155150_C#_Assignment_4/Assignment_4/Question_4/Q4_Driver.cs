﻿using Question_4.StudentRecord;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_4
{
    public class Q4_Driver
    {
        public void Init_Q4()
        {
            bool stopFlag = false;
            int choice;
            string condition;

            Record record = new Record();

            while (!stopFlag)
            {

                try
                {

                    Console.Write("\nEnter your choice :\n 1. To add details of five students \n 2. To search and show the details of student\n ::> ");
                    choice = int.Parse(Console.ReadLine());

                    switch (choice)
                    {

                        case 1:
                            record.GetDetailFromUser();
                            break;

                        case 2:
                            record.Search();
                            record.Display();
                            break;

                        default:
                            Console.WriteLine("Not a valid choice...try again!!");
                            break;

                    }

                    Console.Write("\nEnter Y to continue and N to quit...");
                    condition = Console.ReadLine().ToLower();

                    if (condition.Equals("y"))
                        continue;
                    else if (condition.Equals("n"))
                        stopFlag = true;
                    else
                        Console.WriteLine("Not a valid choice .... try again!!");
                }
                catch(Exception e)
                {
                    Console.WriteLine($"{e.Message} , program restarted !!");
                }
            }
        
        }
    }
}
