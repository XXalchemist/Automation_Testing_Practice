﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_4
{
    // Runner for Q4
    class Runner
    {
        public static void Main(string[] args)
        {

            Q4_Driver Q4 = new Q4_Driver();
            Q4.Init_Q4();
        }
    }
}
