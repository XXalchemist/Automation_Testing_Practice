﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_4.StudentRecord
{
    class Record
    {
        // data variables required for each record
        private long [] rollNumbers;
        private string [] studentNames;
        private int [] ages;
        private int[] classes;
        private double [] percentages;
        private int searchKey;
        private int length = 5;
        private long rollNumber;

        // to get detail of 5 students from user
        public void GetDetailFromUser()
        {
            rollNumbers = new long[5];
            studentNames = new string[5];
            ages = new int[5];
            percentages = new double[5];
            classes = new int[5];

            Console.WriteLine("--- Enter the details for 5 students --- ");
            for (int i = 0; i < length; i++)
            {

                Console.Write($"\nEnter the name of student {i + 1} : ");
                studentNames[i] = Console.ReadLine().ToLower();

                // Avoid sending blank string as student name
                if (studentNames[i].Equals(""))
                    throw new Exception("Empty string !!");

                Console.Write($"Enter the age of student {i + 1} : ");
                ages[i] = int.Parse(Console.ReadLine());

                // to check age (1-70)
                if (ages[i] < 1 || ages[i] > 70)
                    throw new Exception("Invalid age ! (Age lie between 1 - 70)");

                Console.Write($"Enter the rollNumber of student {i + 1} : ");
                rollNumber = long.Parse(Console.ReadLine());

                // to check unique roll number using custom method
                if (ToCheckRoll(rollNumber))
                    throw new Exception("Same roll number exists !");
                
                rollNumbers[i] = rollNumber;

                Console.Write($"Enter the class of student {i + 1} : ");
                classes[i] = int.Parse(Console.ReadLine());

                if (classes[i] > 12 || classes[i] < 1)
                    throw new Exception("Invalid class ! ");

                Console.Write($"Enter the percentage of student {i + 1} : ");
                percentages[i] = double.Parse(Console.ReadLine());

                // to validate that percentage lies between 0-100
                if (percentages[i] < 0 || percentages[i] > 100)
                    throw new Exception("Invalid percentage !!");

            }

        }

        // to search student detail
        public void Search()
        {
            string studentName;
       
            Console.Write("\nEnter the name of student to be searched in database : ");
            studentName = Console.ReadLine().ToLower();

            // We can also use indexOf here
            for(int i = 0; i < length; i++)
            {
                if (studentNames[i].Equals(studentName))
                    searchKey = i;
            }

        }

        // to show detail
        public void Display()
        {
            if (searchKey > 0)
            {

                Console.WriteLine("\nStudent Details Found...");
                Console.WriteLine("------------------------");

                Console.WriteLine($"Student Name : {studentNames[searchKey]}");
                Console.WriteLine($"Student Age : {ages[searchKey]}");
                Console.WriteLine($"Student Class : {classes[searchKey]}");
                Console.WriteLine($"Student Roll Number : {rollNumbers[searchKey]}");
                Console.WriteLine($"Student Percentage : {percentages[searchKey]}");
            }   
            else
                Console.WriteLine("Sorry, there's no match...please try again !!");

        }

        // to validate unique roll number for each student
        public bool ToCheckRoll(long rollNumber)
        {

            for(int i = 0; i < length; i++)
            {
                if (rollNumbers[i] == rollNumber)
                    return true;
              
            }
            return false;
        }
    }
}
