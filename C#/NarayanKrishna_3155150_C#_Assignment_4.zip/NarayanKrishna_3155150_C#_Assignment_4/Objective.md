# Objective

# C# Assignment - 4

1.	Write a program to develop application where it will ask user to provide action in integer ranging from 1 to 4 which means as-
1: Add record		2: Get all records	3: Get a record		4: Delete record
Record consists of id (random number), list of salary amount for 3 months, average salary.
Rules:-

-	Please use enum to work with user action input.
-	User should not be able to assign any value to id and avg. salary from test file.
-	Application should continue working until user is not denying to continue.

2.	Write a program to accept patient count inputs from user for multiple days (days count should be taken from user). 
After getting all records, ask an input from user for following actions-

-	Maximum :- return maximum count of patient along with day number when maximum patients got admitted
-	Minimum :- return minimum count of patient along with day number when minimum patients got admitted
-	Average :- return average patient count for stored data of various days
-	Sum :- return total count of patients admitted along with number of days

3.	Write a program to accept principal amount from user. Then based on user input for CI or SI, calculate CI/SI and display to user. (Take time and yearly ROI from user and user should have option to provide time either in years or months)

4.	Write a program to store 5 students name and their corresponding data. Student data will comprise following info-
Roll No, Age, Class, Percentage ( Case Handling...)
Accept a student name from user and display his data to user.

Try to ensure following things in your solutions-

-	Implement Oops concept wherever possible.
-	Test class should not have any program logic.
-	Don’t use linq query anywhere
-	Code should be clean, modular, and maintainable.

Please create single solution with multiple projects (one for each question). Delete “bin” and “obj” folders and create zip folder for your solution. Upload this zip folder to your google drive and share the link in form.
Zip folder name format-
Naming convention-> "{employee_name}_{employee_id}" [e.g. "Amit Khandelwal_0000000"]