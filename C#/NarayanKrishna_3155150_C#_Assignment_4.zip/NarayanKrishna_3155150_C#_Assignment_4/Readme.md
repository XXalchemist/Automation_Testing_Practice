# C# Assignment - 4

- Consist of 4 Projects in one solution
- Each Project has its own runner class
- Each Project contains :-
	- Record - For performing records related operations
	- Driver - For performing user choices
	- Runner - To run the sproject

## Instructions

- Open Solution
- Select any Project from the solution
- Run the runner class present in each project

## Important Note 

> For every exception or for certain cases ... the program will be restarted.

> The program will work for following exception and cases.

> If user didn't add data and wanted to get it...then it will throw exception and program will be restarted.

## Following are the cases :-

- *Question - 1 :-*
 	
 	- Invalid Choice (input) for given menu.
 	- Invalid condition(input string) for yes and no 
 	- Any of invalid data given by the user

- *Question - 2 :-* 
 	
 	- Invalid Choice (input) for given menu.
 	- Invalid condition(input string) for yes and no 
 	- Any of invalid data given by the user

- *Question - 3 :-*
 	
 	- Invalid Choice (input) for given menu.
 	- Invalid condition(input string) for yes and no 
 	- Any of invalid data given by the user

- *Question - 4 :-*

 	- Invalid Choice (input) for given menu.
 	- Invalid condition(input string) for yes and no 
 	- Any of invalid data given by the user
 	- Check for valid name (not empty string)
 	- Check for valid age (int between 1 - 70)
 	- Check for valid class (int between 1 - 12)
 	- Check for unique roll number
 	- Check for percentage (double between  1 - 100)
