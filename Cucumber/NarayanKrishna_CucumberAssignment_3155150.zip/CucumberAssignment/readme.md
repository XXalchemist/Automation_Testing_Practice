# Cucumber Assignment

AUT – http://automationpractice.com/index.php

- Write 2 feature files with at least 2 tests each
- Use scenario outline/parameterization
- Assignment should follow proper structure and coding guidelines
- Usage of POM & TestNG is must
- Use regular expressions to use same step for multiple scenarios
- Usage of page object model(POM) & Hooks will provide bonus marks


## This assignment includes :-

- Two Positive Testing And Three Negative Testing
- Two Features and 5 scenario outlines

## How to run :-

- Extract the assignment
- Go to the extracted assignment directory and open cmd
- run following command

```cmd
mvn clean install
```

> Extent Report Directory :- ./output/

> Logger Directory        :- ./log/