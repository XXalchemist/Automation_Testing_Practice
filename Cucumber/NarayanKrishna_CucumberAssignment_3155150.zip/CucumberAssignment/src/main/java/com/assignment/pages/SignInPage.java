package com.assignment.pages;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class SignInPage {

	WebDriver driver;
	
	public SignInPage(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
		this.driver = driver;
		signIn.click();
	}
	
	// Flow for the SignIn
	
	@FindBy(how = How.LINK_TEXT, using = "Sign in")
	private WebElement signIn;
	
	@FindBy(how = How.ID, using = "email")
	private WebElement email;
	
	@FindBy(how = How.ID, using = "passwd")
	private WebElement password;
	
	@FindBy(how = How.ID, using = "SubmitLogin")
	private WebElement logIn;
	
	
	
	public void clickSignIn() {
		
		signIn.click();
	}
	
	public void enterEmail(String emailID) {
		
		email.sendKeys(emailID);
	}
	
	public void enterPassword(String pass) {
		
		password.sendKeys(pass);
	}
	
	public void clickLogin() {
		
		logIn.click();
	}
	
	public void validateSignInPage() {
		
		boolean flag = driver.getTitle().equals("My account - My Store");
		
		if (flag == true){
			assertTrue(true);
			System.out.println("--- Valid Details for Sign in ---");
		}	
		else if (flag == false) {
			assertFalse(false);
			System.out.println("--- Invalid Details for Sign in ---");
		}
		else {
			System.out.println("Nothing to assert in Sign In Page..");
		}
		
	}
	
}
