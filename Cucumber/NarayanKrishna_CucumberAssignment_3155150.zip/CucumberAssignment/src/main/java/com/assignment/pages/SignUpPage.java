package com.assignment.pages;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class SignUpPage {
	
    WebDriver driver;
	
	public SignUpPage(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}
	
	// Flow for the creating new account
	
	@FindBy(how = How.LINK_TEXT, using = "Sign in")
	private WebElement signIn;
	
	@FindBy(how = How.NAME, using = "email_create")
	private WebElement emailFirstScreen;
	
	@FindBy(how = How.NAME, using = "SubmitCreate")
	private WebElement createAnAccount;
	
	@FindBy(how = How.NAME, using = "customer_firstname")
	private WebElement firstName;
	
	@FindBy(how = How.NAME, using = "customer_lastname")
	private WebElement lastName;
	
	@FindBy(how = How.ID, using = "passwd")
	private WebElement password;
	
	@FindBy(how = How.NAME, using = "address1")
	private WebElement address;
	
	@FindBy(how = How.NAME, using = "city")
	private WebElement address_city;
	
	@FindBy(how = How.NAME, using = "id_state")
	private WebElement state;
	
	@FindBy(how = How.NAME, using = "postcode")
	private WebElement postCode;
	
	@FindBy(how = How.NAME, using = "id_country")
	private WebElement country;
	
	@FindBy(how = How.NAME, using = "phone_mobile")
	private WebElement phone_mobile;
	
	@FindBy(how = How.NAME, using = "alias")
	private WebElement alias;
	
	@FindBy(how = How.NAME, using = "submitAccount")
	private WebElement register;
	
	
	// First Screen
	public void clickSignIn() {
		
		signIn.click();
	}
	
	public void enterEmail(String emailID) {
		
		emailFirstScreen.sendKeys(emailID);
	}

	public void clickOnCreateAnAccount() {
		
		createAnAccount.click();
	}
	
	// Selection menu
	public void selectMenu(String stateName) {
		
		Select countrySelect = new Select(country);
		countrySelect.selectByVisibleText("United States");
		
		Select stateSelect = new Select(state);
		stateSelect.selectByVisibleText(stateName);
	}
	
	// Second Screen
	public void enterDetails(String firstname, String lastname, String passwordVar, String addressVar, String cityname, String mobile, String addressAlias, String postalCode ) {
		
		firstName.sendKeys(firstname);
		lastName.sendKeys(lastname);
		password.sendKeys(passwordVar);
		address.sendKeys(addressVar);
		postCode.sendKeys(postalCode);
		address_city.sendKeys(cityname);
		phone_mobile.sendKeys(mobile);
		alias.clear();
		alias.sendKeys(addressAlias);
		
	}
	
	
	// To create new account
	public void clickOnRegister() {
		
		register.click();
	}
	
	// to validate current page
	public void toValidateCurrentPage() {
		
		boolean flag = driver.getTitle().equals("My account - My Store");

		if (flag == true) {
			assertTrue(true);
			System.out.println("--- Valid Details for Sign up ---");
		} else if (flag == false) {
			assertFalse(false);
			System.out.println("--- Invalid Details for Sign up ---");
		} else {
			System.out.println("Nothing to assert in Sign Up Page..");
		}
	}

}
