package com.assignment.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;




public class BaseTest {
	
	public static WebDriver driver;
	public static Properties prop = new Properties();
	
	public static File file = new File("./src/main/java/com/assignment/config/configuration.properties");
	public static FileInputStream fis = null;
	
	
	// Creating and using properties file
	static { 
		// Exception Handling for FIS
		try {
			
			fis = new FileInputStream(file);
		}catch(FileNotFoundException e){
			
			System.out.println(e.getMessage());
		}
		// Exception Handling for Prop
		try {
			
			prop.load(fis);
		}catch(IOException e) {
			
			System.out.println(e.getMessage());
		}
		
	}
	

	public static void initDriver() {
		String browsername = prop.getProperty("browser");
		
		if (browsername.equals("chrome")) {
			
			System.setProperty("webdriver.chrome.driver",prop.getProperty("chromePath"));
			driver = new ChromeDriver();
		}
		
		else if (browsername.equals("firefox")){
			
			System.setProperty("webdriver.gecko.driver", prop.getProperty("firefoxPath"));
			driver  = new FirefoxDriver();
		}
		
		else
			System.out.println("Browser not present...");
	}
	
	
	public static void openUrl() {
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		driver.get("http://automationpractice.com/index.php");
	}
	
	
	public static void closeBrowser() {
		
		driver.close();
		driver.quit();
	}
	
}
