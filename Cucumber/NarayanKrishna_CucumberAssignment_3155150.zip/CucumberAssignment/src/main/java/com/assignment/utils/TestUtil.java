package com.assignment.utils;

import java.util.Date;

public class TestUtil {
	
	static final int PAGE_LOAD_TIMEOUT = 20;
	static final int IMPLICIT_WAIT = 30;
	
	
	public static String createFileName() {
		
		String fileName = null;
		Date currDate = new Date();
		fileName = currDate.toString().replace(':', '_');
		System.out.println("File name assigned : "+currDate);
		return fileName;
	}

}
