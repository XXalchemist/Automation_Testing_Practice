package com.assignment.StepDefinitions;


import com.assignment.pages.SignInPage;
import com.assignment.utils.BaseTest;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SignInStepDef extends BaseTest{
	
	
	SignInPage signInPage = null;
	
	@Before
	public void setUpBrowser() {
		
		BaseTest.initDriver();
		BaseTest.openUrl();
	}
	
	
	
	
	@After
	public void tearDownBrowser() {
		
		BaseTest.closeBrowser();
	}
	
	
	@Given("^User already opened browser and on SignIn page$")
	public void user_already_opened_browser_and_on_signIn_page() throws Throwable {
		
		signInPage = new SignInPage(driver);
		signInPage.clickSignIn();
	}

	@When("^User enters (?:valid|invalid) '(.*)' and (?:valid|invalid) '(.*)'$")
	public void user_enter_email_and_password(String emailID, String pass ) {
		
		signInPage.enterEmail(emailID);
		signInPage.enterPassword(pass);
	}

	@When("^User clicks on login button$")
	public void user_clicks_on_login_button() throws Throwable {
	    
		signInPage.clickLogin();
	}

	@Then("^Validate user is correctly logged in or not$")
	public void validate_user_is_correctly_logged_in_or_not() throws Throwable {
	    
		signInPage.validateSignInPage();
	
	}
	
}
