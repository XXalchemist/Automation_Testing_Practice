package com.assignment.StepDefinitions;

import com.assignment.pages.SignUpPage;
import com.assignment.utils.BaseTest;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SignUpStepDefs extends BaseTest {
	
	
	SignUpPage signUpPage = null; 
	
	@Given("^User on the first signUp screen$")
	public void user_on_the_first_signUp_screen() throws Throwable {
	   
	   signUpPage = new SignUpPage(driver);
	   signUpPage.clickSignIn();
	}

	@When("^User enters the (?:valid|invalid) '(.*)' on first screen$")
	public void user_enters_the_newEmailAccount_gmail_com_on_first_screen(String email) throws Throwable {
	    
		signUpPage.enterEmail(email);
	}

	@Then("^User clicks on Create an account button$")
	public void user_clicks_on_Create_an_account_button() throws Throwable {
	  
		signUpPage.clickOnCreateAnAccount();
	}

	@When("^User enters valid '(.*)', '(.*)', '(.*)', '(.*)', '(.*)', '(.*)', '(.*)', '(.*)' and '(.*)'$")
	public void user_enters_details(String firstname, String lastname, String passwordVar, String addressVar, String city_name, String state_name, String postalCode, String mobile, String addressAlias) throws Throwable {

		signUpPage.enterDetails(firstname, lastname, passwordVar, addressVar, city_name, mobile, addressAlias, postalCode);
	    signUpPage.selectMenu(state_name);
	}

	@Then("^User clicks on Register button$")
	public void user_clicks_on_Register_button() throws Throwable {
	    
	    signUpPage.clickOnRegister();
	}

	@Then("^Validate User account creation$")
	public void validate_User_account_creation() throws Throwable {
		
	    signUpPage.toValidateCurrentPage();
	}
}
