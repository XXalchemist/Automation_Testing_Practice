package com.assignment.TestRunner;

import java.io.File;


import org.testng.annotations.AfterClass;

import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
		features = "src/test/java/com/assignment/Features/", 
		glue = { "com/assignment/StepDefinitions/" }, // path of step definition
		plugin = { "com.cucumber.listener.ExtentCucumberFormatter:output/Extent_Test_report.html"}, 
		monochrome = false, // display console output in a readable format
		dryRun = false, // check all the steps have the definitions and will not execute
		strict = true ) // check if any step is not defined in step definition file
		//tags = { "@Smoke" })

//public class TestRunner extends AbstractTestNGCucumberTests {

//}


public class TestRunner extends AbstractTestNGCucumberTests {
	@AfterClass
	public static void reportGenerate() {

		Reporter.loadXMLConfig(new File("com/assignment/config/extent-config.xml"));
		Reporter.setSystemInfo("user", System.getProperty("user.name"));
		Reporter.setSystemInfo("os", "Window 10");
		Reporter.setTestRunnerOutput("Extent Report Generated");
	}
}
