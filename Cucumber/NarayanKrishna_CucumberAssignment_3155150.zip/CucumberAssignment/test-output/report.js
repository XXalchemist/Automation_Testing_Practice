$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("signIn.feature");
formatter.feature({
  "line": 1,
  "name": "AutomationPractice.com signIn Test",
  "description": "For checking valid and invalid signIn",
  "id": "automationpractice.com-signin-test",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 5,
  "name": "Valid SignIn with valid username and valid password Scenario Outline",
  "description": "",
  "id": "automationpractice.com-signin-test;valid-signin-with-valid-username-and-valid-password-scenario-outline",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 4,
      "name": "@ValidSignInTest"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "User is already opened browser",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User open SignIn page",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "User enters valid \u0027\u003cemail\u003e\u0027 and valid \u0027\u003cpassword\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "User clicks on login button",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Validate user is correctly logged in or not",
  "keyword": "Then "
});
formatter.examples({
  "line": 12,
  "name": "",
  "description": "",
  "id": "automationpractice.com-signin-test;valid-signin-with-valid-username-and-valid-password-scenario-outline;",
  "rows": [
    {
      "cells": [
        "email",
        "password"
      ],
      "line": 13,
      "id": "automationpractice.com-signin-test;valid-signin-with-valid-username-and-valid-password-scenario-outline;;1"
    },
    {
      "cells": [
        "newUser@gmail.com",
        "123456"
      ],
      "line": 14,
      "id": "automationpractice.com-signin-test;valid-signin-with-valid-username-and-valid-password-scenario-outline;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 14,
  "name": "Valid SignIn with valid username and valid password Scenario Outline",
  "description": "",
  "id": "automationpractice.com-signin-test;valid-signin-with-valid-username-and-valid-password-scenario-outline;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 4,
      "name": "@ValidSignInTest"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "User is already opened browser",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User open SignIn page",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "User enters valid \u0027newUser@gmail.com\u0027 and valid \u0027123456\u0027",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "User clicks on login button",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Validate user is correctly logged in or not",
  "keyword": "Then "
});
formatter.match({
  "location": "SignInStepDef.user_is_already_opened_browser()"
});
formatter.result({
  "duration": 18899362300,
  "status": "passed"
});
formatter.match({
  "location": "SignInStepDef.user_is_on_login_page()"
});
formatter.result({
  "duration": 699500,
  "error_message": "java.lang.NullPointerException: Cannot invoke \"org.openqa.selenium.SearchContext.findElement(org.openqa.selenium.By)\" because \"this.searchContext\" is null\r\n\tat org.openqa.selenium.support.pagefactory.DefaultElementLocator.findElement(DefaultElementLocator.java:69)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:38)\r\n\tat com.sun.proxy.$Proxy22.click(Unknown Source)\r\n\tat com.assignment.pages.SignInPage.clickSignIn(SignInPage.java:39)\r\n\tat com.assignment.StepDefinitions.SignInStepDef.user_is_on_login_page(SignInStepDef.java:24)\r\n\tat ✽.Then User open SignIn page(signIn.feature:7)\r\n",
  "status": "failed"
});
formatter.match({
  "arguments": [
    {
      "val": "newUser@gmail.com",
      "offset": 19
    },
    {
      "val": "123456",
      "offset": 49
    }
  ],
  "location": "SignInStepDef.user_enter_email_and_password(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "SignInStepDef.user_clicks_on_login_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "SignInStepDef.validate_user_is_correctly_logged_in_or_not()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenarioOutline({
  "line": 17,
  "name": "Invalid SignIn with valid username and invalid password Scenario Outline",
  "description": "",
  "id": "automationpractice.com-signin-test;invalid-signin-with-valid-username-and-invalid-password-scenario-outline",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 16,
      "name": "@InvalidSignInTest"
    }
  ]
});
formatter.step({
  "line": 18,
  "name": "User is already opened browser",
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "User open SignIn page",
  "keyword": "Then "
});
formatter.step({
  "line": 20,
  "name": "User enters valid \u0027\u003cemail\u003e\u0027 and invalid \u0027\u003cpassword\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "User clicks on login button",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "Validate user is correctly logged in or not",
  "keyword": "Then "
});
formatter.examples({
  "line": 24,
  "name": "",
  "description": "",
  "id": "automationpractice.com-signin-test;invalid-signin-with-valid-username-and-invalid-password-scenario-outline;",
  "rows": [
    {
      "cells": [
        "email",
        "password"
      ],
      "line": 25,
      "id": "automationpractice.com-signin-test;invalid-signin-with-valid-username-and-invalid-password-scenario-outline;;1"
    },
    {
      "cells": [
        "newUser@gmail.com",
        "abC@xyz"
      ],
      "line": 26,
      "id": "automationpractice.com-signin-test;invalid-signin-with-valid-username-and-invalid-password-scenario-outline;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 26,
  "name": "Invalid SignIn with valid username and invalid password Scenario Outline",
  "description": "",
  "id": "automationpractice.com-signin-test;invalid-signin-with-valid-username-and-invalid-password-scenario-outline;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 16,
      "name": "@InvalidSignInTest"
    }
  ]
});
formatter.step({
  "line": 18,
  "name": "User is already opened browser",
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "User open SignIn page",
  "keyword": "Then "
});
formatter.step({
  "line": 20,
  "name": "User enters valid \u0027newUser@gmail.com\u0027 and invalid \u0027abC@xyz\u0027",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "User clicks on login button",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "Validate user is correctly logged in or not",
  "keyword": "Then "
});
formatter.match({
  "location": "SignInStepDef.user_is_already_opened_browser()"
});
formatter.result({
  "duration": 21899987000,
  "status": "passed"
});
formatter.match({
  "location": "SignInStepDef.user_is_on_login_page()"
});
formatter.result({
  "duration": 14298680800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "newUser@gmail.com",
      "offset": 19
    },
    {
      "val": "abC@xyz",
      "offset": 51
    }
  ],
  "location": "SignInStepDef.user_enter_email_and_password(String,String)"
});
formatter.result({
  "duration": 138382600,
  "status": "passed"
});
formatter.match({
  "location": "SignInStepDef.user_clicks_on_login_button()"
});
formatter.result({
  "duration": 9109836700,
  "status": "passed"
});
formatter.match({
  "location": "SignInStepDef.validate_user_is_correctly_logged_in_or_not()"
});
formatter.result({
  "duration": 6602800,
  "error_message": "java.lang.AssertionError: expected [true] but found [false]\r\n\tat org.testng.Assert.fail(Assert.java:93)\r\n\tat org.testng.Assert.failNotEquals(Assert.java:512)\r\n\tat org.testng.Assert.assertTrue(Assert.java:41)\r\n\tat org.testng.Assert.assertTrue(Assert.java:51)\r\n\tat com.assignment.pages.SignInPage.validateSignInPage(SignInPage.java:59)\r\n\tat com.assignment.StepDefinitions.SignInStepDef.validate_user_is_correctly_logged_in_or_not(SignInStepDef.java:43)\r\n\tat ✽.Then Validate user is correctly logged in or not(signIn.feature:22)\r\n",
  "status": "failed"
});
formatter.scenarioOutline({
  "line": 29,
  "name": "Invalid SignIn valid username and invalid password Scenario Outline",
  "description": "",
  "id": "automationpractice.com-signin-test;invalid-signin-valid-username-and-invalid-password-scenario-outline",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 28,
      "name": "@InvalidSignInTest"
    }
  ]
});
formatter.step({
  "line": 30,
  "name": "User is already opened browser",
  "keyword": "Given "
});
formatter.step({
  "line": 31,
  "name": "User open SignIn page",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "User enters invalid \u0027\u003cemail\u003e\u0027 and valid \u0027\u003cpassword\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 33,
  "name": "User clicks on login button",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "Validate user is correctly logged in or not",
  "keyword": "Then "
});
formatter.examples({
  "line": 36,
  "name": "",
  "description": "",
  "id": "automationpractice.com-signin-test;invalid-signin-valid-username-and-invalid-password-scenario-outline;",
  "rows": [
    {
      "cells": [
        "email",
        "password"
      ],
      "line": 37,
      "id": "automationpractice.com-signin-test;invalid-signin-valid-username-and-invalid-password-scenario-outline;;1"
    },
    {
      "cells": [
        "notAnewUser",
        "123456"
      ],
      "line": 38,
      "id": "automationpractice.com-signin-test;invalid-signin-valid-username-and-invalid-password-scenario-outline;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 38,
  "name": "Invalid SignIn valid username and invalid password Scenario Outline",
  "description": "",
  "id": "automationpractice.com-signin-test;invalid-signin-valid-username-and-invalid-password-scenario-outline;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 28,
      "name": "@InvalidSignInTest"
    }
  ]
});
formatter.step({
  "line": 30,
  "name": "User is already opened browser",
  "keyword": "Given "
});
formatter.step({
  "line": 31,
  "name": "User open SignIn page",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "User enters invalid \u0027notAnewUser\u0027 and valid \u0027123456\u0027",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 33,
  "name": "User clicks on login button",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "Validate user is correctly logged in or not",
  "keyword": "Then "
});
formatter.match({
  "location": "SignInStepDef.user_is_already_opened_browser()"
});
formatter.result({
  "duration": 3831324500,
  "status": "passed"
});
formatter.match({
  "location": "SignInStepDef.user_is_on_login_page()"
});
formatter.result({
  "duration": 970498800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "notAnewUser",
      "offset": 21
    },
    {
      "val": "123456",
      "offset": 45
    }
  ],
  "location": "SignInStepDef.user_enter_email_and_password(String,String)"
});
formatter.result({
  "duration": 20981900,
  "error_message": "org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {\"method\":\"css selector\",\"selector\":\"#email\"}\n  (Session info: chrome\u003d86.0.4240.198)\nFor documentation on this error, please visit: https://www.seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027NARAYANKRISHNA\u0027, ip: \u0027192.168.43.95\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u002714.0.2\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 86.0.4240.198, chrome: {chromedriverVersion: 86.0.4240.22 (398b0743353ff..., userDataDir: C:\\Users\\NARAYA~1\\AppData\\L...}, goog:chromeOptions: {debuggerAddress: localhost:61082}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:virtualAuthenticators: true}\nSession ID: 62149e7bc734ff124aca5844f382b2ad\n*** Element info: {Using\u003did, value\u003demail}\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat java.base/jdk.internal.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.base/java.lang.reflect.Constructor.newInstanceWithCaller(Constructor.java:500)\r\n\tat java.base/java.lang.reflect.Constructor.newInstance(Constructor.java:481)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:323)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementById(RemoteWebDriver.java:372)\r\n\tat org.openqa.selenium.By$ById.findElement(By.java:188)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:315)\r\n\tat org.openqa.selenium.support.pagefactory.DefaultElementLocator.findElement(DefaultElementLocator.java:69)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:38)\r\n\tat com.sun.proxy.$Proxy22.sendKeys(Unknown Source)\r\n\tat com.assignment.pages.SignInPage.enterEmail(SignInPage.java:44)\r\n\tat com.assignment.StepDefinitions.SignInStepDef.user_enter_email_and_password(SignInStepDef.java:30)\r\n\tat ✽.When User enters invalid \u0027notAnewUser\u0027 and valid \u0027123456\u0027(signIn.feature:32)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "SignInStepDef.user_clicks_on_login_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "SignInStepDef.validate_user_is_correctly_logged_in_or_not()"
});
formatter.result({
  "status": "skipped"
});
});