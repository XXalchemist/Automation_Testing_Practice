

// ATMtransaction

class ATMtransaction{
	
	private String choice;
	
	public void execute(String transactionType) throws UnsupportedTransactionException {
	System.out.println("\nExecuting......");
	choice = transactionType.toLowerCase();
	
	switch(choice) {
	
	case "credit" : System.out.println("Welcome to the credit section");
	break;
	
	case "debit" : System.out.println("Welcome to the debit section");
	break;
	
	case "balanceenquiry" : System.out.println("Welcome to the balanceenquiry section");
	break;
	
	case "pinchange" : System.out.println("Welcome to the pinchange section");
	break;
	
	default : throw new UnsupportedTransactionException();
	
	}
	}
}

// Custom Exception

class UnsupportedTransactionException extends Exception{
	
	public String getException() {
		
		return "Incorrect Value";
	}
}


public class Test {

	public static void main(String[] args) {
	
		ATMtransaction t1 = new ATMtransaction();
		System.out.println("Checking if TransactionType is credit");
		
		try {
			
		t1.execute("Credit");
		}
		
		catch(UnsupportedTransactionException e) {
			
			System.out.println("Exception occurs : "+e.getMessage());
		}
		
		try {
			
		
		System.out.println("\nChecking if TransactionType is not valid");
		t1.execute("NotCredit");
		}
		
		catch (UnsupportedTransactionException e) {
			
			System.out.println("Exception occurs : "+e.getException());
		}
		
	}
		

	}

