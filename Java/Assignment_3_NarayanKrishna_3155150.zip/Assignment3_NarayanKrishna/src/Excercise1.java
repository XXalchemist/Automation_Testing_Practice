/*  Create a String: �A quick brown fox jumps over the lazy dog.�
*	Get the index of character �d�.
*	Get the character at index twice the first instance of �w�.
*	Get a substring from index 15 to 22.
*	Convert the string to Uppercase.
*	Get the last index of character �u�
*	Append �in the night� to the above string.
*/

public class Excercise1 {

	public static void main(String[] args) {
		
		// Create a string
		
		String sentence = "A quick brown fox jumps over the lazy dog.";
		
		// Index of 'd'
		
		System.out.println("1. Index of 'd' : "+sentence.indexOf('d'));
		
		// Character at index (2*instance of 'w')
		
		int ind = 2*sentence.indexOf('w'); 
		System.out.println("2. Character at "+ind+" : "+sentence.charAt(ind));
		
		// Substring from index 15 to 22
		
		System.out.println("3. Substring from 15 - 22 : "+sentence.substring(15, 22));
		
		// Convert the given string to uppercase
		
		System.out.println("4. Given sentence in uppercase : "+sentence.toUpperCase());
		
		// Get the last index of 'u'
		
		System.out.println("5. Index of 'u' from last : "+sentence.lastIndexOf('u'));
		
		// Append in the night to the given string
		
		System.out.println("6. Append 'in the night' to the given sentence : "+sentence.concat("in the night"));
		
	}

}
