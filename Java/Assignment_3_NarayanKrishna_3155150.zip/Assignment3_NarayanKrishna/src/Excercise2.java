/* Calculate the frequency of each word in the given string
   "the quick brown fox jumps fox fox over the lazy dog brown"
 */
import java.util.Hashtable;

public class Excercise2 {

	public static void main(String[] args) {
		
		String sentence = "the quick brown fox jumps fox fox over the lazy dog brown";
		
		// Converting the given string into words array
		
		String [] words = sentence.split(" ");
		
		// Creating WordCounts HashTable to store count of each words
		
		Hashtable<String,Integer>wordCounts = new Hashtable <String,Integer>();
		
		for (String word : words) {
			
			if(wordCounts.containsKey(word)) {
				
				wordCounts.put(word, wordCounts.get(word)+1);
			}
			else
				// Fixes from initializing with 0 to 1
				wordCounts.put(word,1);
		}
		
		/*System.out.println(wordCounts.keySet());
		System.out.println(wordCounts.values());
		*/
		
		// To print word and its count'
		
		System.out.println("------ WordCount in the given sentence ------\n\n "+sentence+"\n");
		for(String word : wordCounts.keySet()) {
			System.out.println(" Word ["+word+"] : "+ wordCounts.get(word));
		}
	}
		

}
