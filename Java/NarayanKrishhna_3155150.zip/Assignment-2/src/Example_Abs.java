// Create abstract class and its implementation
abstract class Car {
	
	int fuelCapacity = 50;
	
	
	public void move() {
	
	}
	
	public void start() {
		
	}

	public void notToUse() {
		
	}
}

class Sedan extends Car {
	
	@Override
	public void move() {
		System.out.println("Sedan moving ------ ");
	}
	
	@Override
	public void start() {
		System.out.println("Sedan started -----");
	}

}

public class Example_Abs{
	
	public static void main(String[] args) {
		
		Car A = new Sedan();
		A.start();
		A.move();
		A.notToUse();
	}
}