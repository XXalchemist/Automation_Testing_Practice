// Create interface and its implementation

interface School{
	
	// Interface all methods should be implemented to its child class
	
	public void schedules();
	public void teachers();
	public void students();
}

class PrivSchool implements School{
	
	@Override
	public void schedules() {
		System.out.println("Schedule for Priv School------");
	}

	@Override
	public void teachers() {
		System.out.println("Teachers List for Priv School------");
	}

	@Override
	public void students() {
		System.out.println("Students List for Priv School------");
		
	}
}



public class Example_Interface {

	public static void main(String[] args) {
		
		School A = new PrivSchool();
		A.teachers();
		A.students();
		A.schedules();
	}

}
