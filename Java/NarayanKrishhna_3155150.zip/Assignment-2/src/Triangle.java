/* Create a class Triangle. 
Use the static keyword to count the number of instances of Triangle being created.*/

public class Triangle {
	static int count = 0;
	
	public Triangle() {
		System.out.println("New triangle created");
		count++;
	}
	
	public static void countTriangle() {
		System.out.println("Total number of instances created : "+ count+"\n");
	}
	
	public static void main(String[] args) {
		
		Triangle a = new Triangle();
		a.countTriangle(); // Not a static way to access
		
		Triangle.countTriangle(); // static way to access
		
		Triangle b = new Triangle();
		
		Triangle.countTriangle();
	}

}
