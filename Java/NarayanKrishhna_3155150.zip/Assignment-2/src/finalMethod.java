// Create a final method in it. Now create a sub-class and try to override it

public class finalMethod {

	public static void main(String[] args) {
		

	}
	
	final public void methodOverride() {
		System.out.print("This is original method");
	}

}

class Test extends finalMethod{
	
	// Error can't override the final method
	
	@Override
	public void methodOverride() {
		System.out.print("This is overriden method");
	}
	
	
}
