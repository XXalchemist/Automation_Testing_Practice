/* Create a class and declare a final variable and initialize it to some value.
   Now try to re-assign it a new value.*/

public class finalVal {
	
	final static int var = 10;
	
	public static void main(String[] args) {
		
		System.out.println("Var : "+var);
		
		// Error : Final value can't be reassigned
		var = 11;
		
	}

}
