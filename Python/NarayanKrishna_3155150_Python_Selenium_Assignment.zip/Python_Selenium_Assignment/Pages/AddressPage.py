"""
Contains functions needed for performing actions to change and delete address
"""
from selenium.webdriver.common.by import By

# pre requirement for all address test cases
from selenium.webdriver.support.select import Select


def address_prerequiste(driver, email_id, password):
    sign_in = driver.find_element(By.LINK_TEXT, "Sign in")
    sign_in.click()
    email_field = driver.find_element(By.ID, "email")
    email_field.send_keys(email_id)
    password_field = driver.find_element(By.ID, "passwd")
    password_field.send_keys(password)
    submitBtn = driver.find_element(By.ID, "SubmitLogin")
    submitBtn.click()


# change only basic address for the product delivery
def update_address(driver, firstName, lastName, addressVar, city_name, state_name, country_name, mobileNo, post_code,
                   addressAlias):
    # click on address
    address_link = driver.find_element(By.XPATH, '//*[@title = "Addresses"]')
    address_link.click()
    # click on new address
    new_address_element = driver.find_element(By.XPATH, '//*[@title = "Add an address"]')
    new_address_element.click()
    # send data to the form
    # elements
    firstname = driver.find_element(By.NAME, "firstname")
    lastname = driver.find_element(By.NAME, "lastname")
    address = driver.find_element(By.NAME, "address1")
    city = driver.find_element(By.NAME, "city")
    state = driver.find_element(By.NAME, "id_state")
    postal_code = driver.find_element(By.NAME, "postcode")
    country = driver.find_element(By.NAME, "id_country")
    mobile = driver.find_element(By.NAME, "phone_mobile")
    alias = driver.find_element(By.NAME, "alias")
    create_account = driver.find_element(By.NAME, "submitAddress")

    # actions
    country_select = Select(country)
    country_select.select_by_visible_text(country_name)
    state_select = Select(state)
    state_select.select_by_visible_text(state_name)
    firstname.send_keys(firstName)
    lastname.send_keys(lastName)
    address.send_keys(addressVar)
    city.send_keys(city_name)
    mobile.send_keys(mobileNo)
    postal_code.send_keys(post_code)
    alias.clear()
    alias.send_keys(addressAlias)
    create_account.click()


def delete_address(driver):
    # address click
    # click on address
    address_link = driver.find_element(By.XPATH, '//*[@title = "Addresses"]')
    address_link.click()

    # delete the last added address - check without span
    delete_btns = driver.find_elements(By.XPATH, '//*/li[@class = "address_update"]/a[@title = "Delete"]/span')

    # deleting last element
    print(f"Delete Buttons List : {delete_btns}")
    delete_btns[-1].click()

    alert_box = driver.switch_to.alert
    alert_box.accept()


def validate_result(driver, alias_name):
    # check that address exist or not
    alias_name = alias_name.lower()
    list_of_address = driver.find_elements(By.XPATH,
                                           '//*/div[@class = "addresses"]/*/div/ul/li/h3[@class = "page-subheading"]')
    list_of_alias_name = []

    # to verify that same alias exists or not
    for element in list_of_address:
        element_name = element.text.lower()
        list_of_alias_name.append(element_name)

    # To print all addresses alias in console
    print(f"list_of_alias : {list_of_alias_name} and Alias name {alias_name}")
    if alias_name in list_of_alias_name:
        return True
    else:
        return False
