"""
Login Page
"""
from selenium.webdriver.common.by import By


# Actions
def click_sign_in(driver):
    sign_in = driver.find_element(By.LINK_TEXT, "Sign in")
    sign_in.click()


def enter_email(driver, email_id):
    email_field = driver.find_element(By.ID, "email")
    email_field.send_keys(email_id)


def enter_password(driver, password):
    password_field = driver.find_element(By.ID, "passwd")
    password_field.send_keys(password)


def click_on_submit(driver):
    submitBtn = driver.find_element(By.ID, "SubmitLogin")
    submitBtn.click()
