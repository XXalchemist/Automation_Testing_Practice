"""
Contains all methods and elements needed for RegistrationTests
"""
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from Utilities import Common_Utils
from Tests import BaseTest

# Actions
def click_sign_in(driver):
    sign_In = driver.find_element(By.LINK_TEXT, "Sign in")
    sign_In.click()


def enter_email(driver, email_id):
    email_first_screen = driver.find_element(By.NAME, "email_create")
    email_first_screen.send_keys(email_id)


def click_register(driver):
    register = driver.find_element(By.NAME, "SubmitCreate")
    register.click()


def select_state_name(driver, country_name, state_name):
    country = driver.find_element(By.NAME, "id_country")
    state = driver.find_element(By.NAME, "id_state")
    country_select = Select(country)
    country_select.select_by_visible_text(country_name)

    state_select = Select(state)
    state_select.select_by_visible_text(state_name)


# Second Screen
def enter_details(driver, firstName, lastName, passWord, addressVar, cityName, mobileNo, addressAlias, postalCode):
    firstname = driver.find_element(By.ID, "customer_firstname")

    # Explicit wait
    lastname = driver.find_element(By.ID, "customer_lastname")
    password = driver.find_element(By.ID, "passwd")
    address = driver.find_element(By.NAME, "address1")
    city = driver.find_element(By.NAME, "city")
    postal_code = driver.find_element(By.NAME, "postcode")
    mobile = driver.find_element(By.NAME, "phone_mobile")
    alias = driver.find_element(By.NAME, "alias")

    firstname.send_keys(firstName)
    lastname.send_keys(lastName)
    password.send_keys(passWord)
    address.send_keys(addressVar)
    city.send_keys(cityName)
    mobile.send_keys(mobileNo)
    postal_code.send_keys(postalCode)
    alias.clear()
    alias.send_keys(addressAlias)


def create_new_account(driver):
    create_account = driver.find_element(By.NAME, "submitAccount")
    create_account.click()
