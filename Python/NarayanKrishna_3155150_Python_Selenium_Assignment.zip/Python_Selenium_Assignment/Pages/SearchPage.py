"""
Contains actions needed for search on the website
"""
from selenium.webdriver.common.by import By


def search_product(driver, product_name):
    # enter product name in searchbox
    searchbox = driver.find_element(By.XPATH, "//input[@id='search_query_top']")

    searchbox.clear()
    searchbox.send_keys(product_name)

    # submit the search
    search_btn = driver.find_element(By.NAME, "submit_search")
    search_btn.click()



def validate_search_result(driver, product_name):
    # match the search result through the search item name
    searched_result = driver.find_elements(By.XPATH, '//*/div[@class = "right-block"]/*/a[@class = "product-name"]')
    actual_product_name = product_name.lower()
    list_of_search_result = []

    # getting the title of result
    for element in searched_result:
        element_name = element.text.lower()
        list_of_search_result.append(element_name)

    # showing all result
    print(f"searched product {list_of_search_result}")
    # verifying result
    if actual_product_name in list_of_search_result:
        return True
    else:
        return False
