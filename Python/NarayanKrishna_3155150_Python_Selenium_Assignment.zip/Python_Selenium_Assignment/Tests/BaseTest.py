"""
Consists of methods needed by the tests
"""
from selenium import webdriver
from Utilities import Config


# driver location
chrome_driver_location = Config.chrome_driver_location
firefox_driver_location = Config.firefox_driver_location

# Basic Configuration
web_url = Config.base_url
browser = Config.browser_name


# creating a method for future use
def open_browser():
    if browser.lower() == "chrome":
        driver = webdriver.Chrome(chrome_driver_location)
        driver.maximize_window()
        driver.implicitly_wait(5)
        return driver
    elif browser.lower() == "firefox":
        driver = webdriver.Chrome(firefox_driver_location)
        driver.maximize_window()
        driver.implicitly_wait(5)
        return driver
    else:
        raise Exception("Browser not supported. Suggested values are [Chrome,Firefox]")


# open webpage
def open_url(driver):
    print("In open_url method")
    driver.get(web_url)


# close
def close_url(driver):
    driver.quit()

