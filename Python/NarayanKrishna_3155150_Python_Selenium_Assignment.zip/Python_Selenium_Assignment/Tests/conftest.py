"""
Contains all hooks i.e fixtures for the package and class
setup -> initialize driver and quit the driver
init_webpage -> start and close the webpage
"""
import pytest
from selenium import webdriver

from Tests import BaseTest


# runs before each test
@pytest.fixture()
def initiate_driver():
    global driver
    driver = BaseTest.open_browser()
    BaseTest.open_url(driver)
    return driver


# runs after each tests
@pytest.fixture()
def teardown():

    yield
    BaseTest.close_url(driver)

