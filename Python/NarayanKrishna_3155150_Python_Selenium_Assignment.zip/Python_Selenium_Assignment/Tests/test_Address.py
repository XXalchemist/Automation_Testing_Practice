"""
Test cases for Address Page
New Address and Delete Address
"""
import pytest

from Tests import BaseTest
from Pages import AddressPage
from Utilities import TestData_File_Reader, Config, Common_Utils

# Getting test data
worksheet_name = Config.address_sheet_name


# test valid new address entry
@pytest.mark.validNewAddressTest
def test_valid_new_address(initiate_driver, teardown):
    # getting test case data
    testcase_name = "validNewAddress"
    test_data = TestData_File_Reader.read_testdata_file(worksheet_name, testcase_name)
    email = test_data.get("email")
    password = test_data.get("password")
    firstname = test_data.get("firstName")
    lastname = test_data.get("lastName")
    city_name = test_data.get("city")
    state_name = test_data.get("state")
    postal_code = test_data.get("postalCode")
    mobile = test_data.get("mobile")
    alias = test_data.get("alias")
    address = test_data.get("newAddressField")
    country_name = test_data.get("country")

    print("Address Test Started -- Valid New Address")
    Common_Utils.show_data(worksheet_name, testcase_name, test_data)

    AddressPage.address_prerequiste(initiate_driver, email, password)
    AddressPage.update_address(initiate_driver, firstname, lastname, address, city_name, state_name, country_name,
                               mobile, postal_code, alias)

    # assert
    assert_condition = AddressPage.validate_result(initiate_driver, alias)
    assert assert_condition, "Check if heading of the address is present or not"

    print("Address Test Completed -- Valid New Address")


# test valid delete of last address entry
@pytest.mark.validDeleteAddressTest
def test_valid_delete_address(initiate_driver, teardown):
    # getting test case data
    testcase_name = "validDeleteAddress"
    test_data = TestData_File_Reader.read_testdata_file(worksheet_name, testcase_name)
    alias = test_data.get("alias")
    email = test_data.get("email")
    password = test_data.get("password")

    print("Address Test Started -- Valid Deletion")

   # preRequiste for delete
    AddressPage.address_prerequiste(initiate_driver, email, password)
    AddressPage.delete_address(initiate_driver)

    # assert
    assert_condition = AddressPage.validate_result(initiate_driver, alias_name=alias)
    assert not assert_condition, "Alias title of old address will be absent"

    print("Address Test Completed -- Valid Deletion")

