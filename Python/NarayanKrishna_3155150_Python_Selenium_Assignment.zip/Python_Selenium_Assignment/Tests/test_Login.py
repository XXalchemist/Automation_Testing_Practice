"""
Login Test
"""
import pytest

from Tests import BaseTest
from Pages import LoginPage
from Utilities import TestData_File_Reader, Config, Common_Utils

# Getting test data
worksheet_name = Config.login_sheet_name

@pytest.mark.validLoginTest
def test_valid_email_and_valid_password_login(initiate_driver, teardown):
    # getting test case data
    testcase_name = "validLogin"
    test_data = TestData_File_Reader.read_testdata_file(worksheet_name, testcase_name)
    email = test_data.get("email")
    password = test_data.get("password")
    expected_title = test_data.get("expected_title").lower()

    print("Login Test Started")
    Common_Utils.show_data(worksheet_name, testcase_name, test_data)

    LoginPage.click_sign_in(initiate_driver)
    LoginPage.enter_email(initiate_driver, email)
    LoginPage.enter_password(initiate_driver, password)
    LoginPage.click_on_submit(initiate_driver)

    # assertion
    actual_result = initiate_driver.title.lower()
    assert actual_result == expected_title, "Login Page Title get matched"
    print("LogIn Test Completed")


# multiple test_Case
@pytest.mark.invalidLoginTest
def test_invalid_email_and_valid_password_login(initiate_driver, teardown):
    # getting test case data
    testcase_name = "invalidLoginWithEmail"
    test_data = TestData_File_Reader.read_testdata_file(worksheet_name, testcase_name)
    email = test_data.get("email")
    password = test_data.get("password")
    expected_title = test_data.get("expected_title").lower()

    print("Login Test Started")
    Common_Utils.show_data(worksheet_name, testcase_name, test_data)

    LoginPage.click_sign_in(initiate_driver)
    LoginPage.enter_email(initiate_driver, email)
    LoginPage.enter_password(initiate_driver, password)
    LoginPage.click_on_submit(initiate_driver)

    # assertion for fail case
    actual_result = initiate_driver.title.lower()
    assert actual_result == expected_title, "Login Page Title was matched"

    print("LogIn Test Completed")
