"""
Include tests for registration screen
"""
import pytest
from Utilities import TestData_File_Reader, Common_Utils, Config
from Pages import RegistrationPage

worksheet_name = Config.register_sheet_name


@pytest.mark.validRegistrationTest
def test_valid_registration(initiate_driver, teardown):
    # getting data from excel file
    testcase_name = "validRegister"

    # Read Test Data From Excel File
    test_data = TestData_File_Reader.read_testdata_file(worksheet_name, testcase_name)

    firstname = test_data.get("firstName")
    lastname = test_data.get("lastName")
    email = test_data.get("email")
    password = test_data.get("password")
    city_name = test_data.get("city")
    state_name = test_data.get("state")
    postal_code = test_data.get("postalCode")
    mobile = test_data.get("mobile")
    alias = test_data.get("alias")
    address = test_data.get("address")
    country_name = test_data.get("country")

    print("Registration Page test started -- Valid Register")
    Common_Utils.show_data(worksheet_name, testcase_name, test_data)

    RegistrationPage.click_sign_in(initiate_driver)
    RegistrationPage.enter_email(initiate_driver, email)
    RegistrationPage.click_register(initiate_driver)

    RegistrationPage.enter_details(initiate_driver, firstName=firstname, lastName=lastname, passWord=password,
                                   addressVar=address, cityName=city_name, mobileNo=mobile, addressAlias=alias,
                                   postalCode=postal_code)
    RegistrationPage.select_state_name(initiate_driver, country_name=country_name, state_name=state_name)
    RegistrationPage.create_new_account(initiate_driver)

    actual_result = initiate_driver.title.lower()
    expected_result = test_data.get("expected_title").lower()

    # assert
    assert actual_result == expected_result, "Check if the current title of web page is as expected"
    print("Registration Test Completed -- Valid Register")

