"""
Search for particular product over the website
"""
import pytest

from Tests import BaseTest
from Pages import SearchPage
from Utilities import TestData_File_Reader, Config, Common_Utils

# Getting test data
worksheet_name = Config.search_sheet_name


@pytest.mark.validSearchTest
def test_valid_search(initiate_driver, teardown):
    testcase_name = "validSearch"
    test_data = TestData_File_Reader.read_testdata_file(worksheet_name, testcase_name)
    product_name = test_data.get("searchProductName")

    print("Search Test Started")
    Common_Utils.show_data(worksheet_name, testcase_name, test_data)

    SearchPage.search_product(initiate_driver, product_name)

    # validate result
    bool_result = SearchPage.validate_search_result(initiate_driver, product_name)

    assert bool_result, "Assert for matching searched product with the result"
    print("Search Test Completed")
