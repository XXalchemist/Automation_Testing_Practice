from Utilities import Config
import time

# for explicit wait
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


# screenshot function
def take_screenshot(driver):
    filename = time.strftime("%Y%m%d-%H%M%S") + ".png"
    screenshot_dir = Config.screenshot_dir + "/" + filename
    try:
        driver.save_screenshot(screenshot_dir)
        print("Screenshot saved successfully")
    except:
        print("Screenshot not saved!")


# show testdata
def show_data(worksheet_name, testcase_name, test_data):
    print(
        f"Test Data : - worksheet_name : {worksheet_name}, testcase_name : {testcase_name}, test_data :{test_data}"
    )


# wait function
# implicit wait
def implicit_wait(driver, time):
    driver.implicitly_wait(time)


# explicit wait
def explicit_wait(driver, time, wait_for_element):
    wait = WebDriverWait(driver, time)
    wait.until(EC.visibility_of_element_located(wait_for_element))
