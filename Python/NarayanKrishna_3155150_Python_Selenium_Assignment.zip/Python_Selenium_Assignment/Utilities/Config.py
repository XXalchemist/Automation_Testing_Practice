"""
Contains all important variables
"""

# Basic configuration
base_url = "http://automationpractice.com/index.php"
browser_name = "chrome"
test_data_file_location = "../Utilities/TestData/TestDataForPythonTraining.xlsx"

# Directory location
screenshot_dir = "Screenshots"
chrome_driver_location = "../Drivers/chromedriver.exe"
firefox_driver_location = "../Drivers/geckodriver.exe"

# All sheet name for test data
register_sheet_name = "RegisterTestData"
login_sheet_name = "LoginTestData"
search_sheet_name = "SearchTestData"
address_sheet_name = "AddressTestData"
