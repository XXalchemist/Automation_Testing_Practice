"""
Reading testdata from excel file
testDataFileLocation = ../TestData/TestDataForPythonTraining.xlsx
"""

# import openpyxl for handling excel file
import openpyxl
from Utilities import Config

# takes sheet name and testcase name to return that testcase data
def read_testdata_file(worksheet_name, testcase_name):
    # load workbook
    book = openpyxl.load_workbook(Config.test_data_file_location)
    # getting sheet
    sheet = book[worksheet_name]
    # getting value as dictionary
    testdata = {}
    for i in range(2, sheet.max_row + 1):
        if sheet.cell(row=i, column=1).value == testcase_name:
            for j in range(2, sheet.max_column + 1):
                testdata[sheet.cell(row=1, column=j).value] = sheet.cell(row=i, column=j).value
            break
    return testdata