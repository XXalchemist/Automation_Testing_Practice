"""
Program 1: Write a program to copy content from one text file to another text file.
Ask file name from user to copy and ask new file which need to be created.

nameOfPrograms.txt present in the textFiles directory
"""

import os.path
from os import path

# base textFiles dir
baseFilesDir = "./textFiles/"

def copyContentOfTextFile(fromFileName, toFileName):

    # file names
    fromFileName = fromFileName + ".txt"
    toFileName  = toFileName + ".txt"

    # open and close both the files
    with open(baseFilesDir + fromFileName, 'r') as fromFile, open(baseFilesDir + toFileName, 'a') as toFile:

        # read content from first file
        for line in fromFile:

            # append content to second file
            toFile.write(line)


def searchForFile(fileName):

    fileName = fileName + ".txt"
    if (path.exists(baseFilesDir+fileName)):
        return True
    else:
        return False


def main():

    # file from which content have to be copied
    print("Files in the given directory ....")
    print(os.listdir(baseFilesDir))
    fromFileName = input("Enter the file name to be copied -> ")

    # search for File (fromFile)
    if(searchForFile(fromFileName)):

        print("File exist ")

        # file to which content copied
        toFileName = input("What you want to name the new file ? -> ")

        copyContentOfTextFile(fromFileName, toFileName)

    else :

        print("File doesn't exist !")

# driver

if __name__ == "__main__":

    main()