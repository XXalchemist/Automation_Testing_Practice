""""
Program 2: Write a program to check in how many lines a word is present in the file.
For e.g. if file has below content
India is a very big country.
New India will be great.
I see lot of opportunities in India.
Then if user sends India then response should be “India is present in 3 lines.”
Note: You do not need to check case india will be same as India

file Required : ./textFiles/Program_2_Helper_textFile
output : {python} : 5 times
"""

def searchCountOfWordInFile(fileName, searchedWord):

    fileName = fileName + ".txt"

    # Create an empty dictionary to store count of all words in file
    wordCounter = dict()

    with open("./textFiles/"+fileName, 'r') as file :

        # Loop each line of the file
        for line in file:

            # Remove the leading spaces and newline character
            line = line.strip()

            # Convert the characters in line to
            # lowercase to avoid case mismatch
            line = line.lower()

            # Split the line into words
            words = line.split(" ")

            # Iterate over each word in line
            for word in words:

                # Check if the word is already in dictionary
                if word in wordCounter:

                    # Increment count of word by 1
                    wordCounter[word] = wordCounter[word] + 1
                else:
                    # Add the word to dictionary with count 1
                    wordCounter[word] = 1

    # Print the count of the given word in file
    if searchedWord in wordCounter.keys():

        print(f"'{searchedWord}' : {wordCounter[searchedWord]}")

    else:

        print(f"'{searchedWord}' not present in given file.")


def main():

    word = input("Enter the word to be searched in file : ")

    # word is converted to lower case ... to make searching easier
    searchedWord = word.lower()

    # fileName
    fileName = "Program_2_Helper_textFile"

    # function call
    searchCountOfWordInFile(fileName, searchedWord)


# driver
if __name__ == "__main__":

    main()