""""
Program 3: Create a calculator program and print below on console.
Welcome to Calculator. You can do below operations.
1-	Add
2-	Subtract
3-	Multiply
4-	Divide
5-	Quit
When user enters valid number then ask for 2 numbers and do operation accordingly and print result and exit the code.
Handle expected exceptions using Try except and add some useful information in finally block and exit the code.
Also raise exception if user enters non integer values.

"""


# Calculator operations
from os import open


def addTwoNumber(firstNumber, secondNumber):
    sum = firstNumber + secondNumber
    return sum


def subTwoNumber(firstNumber, secondNumber):
    sub = firstNumber - secondNumber
    return sub


def mulTwoNumber(firstNumber, secondNumber):
    mul = firstNumber * secondNumber
    return mul


def divTwoNumber(firstNumber, secondNumber):
    # using absolute division operator
    div = firstNumber // secondNumber
    return div


# type check for data that it is integer or not
def intTypeCheck(inputData):
    if inputData.isnumeric():

        return True

    else:

        return False

# calculator
def calculator():

    print('''Welcome to Calculator. You can do below operations.  
            1-	Add
            2-	Subtract
            3-	Multiply
            4-	Divide
            5-	Quit''')

    operationInput = input("Enter the required number for performing operation : ")

    # integer type check
    if not intTypeCheck(operationInput)  :

        raise Exception("Invalid Input ... non integer value! try again")

    # value check
    elif int(operationInput) > 5 :

        raise Exception("Invalid input ! Value greater than 5")

    # quiting the program
    elif int(operationInput) == 5 :

        quit()

    # calculator operations for 1-4
    else :

        # converting it into integer
        operationInput = int(operationInput)

        # take input
        firstNumber = int( input("Enter the first number : "))
        secondNumber = int(input("Enter the second number : "))

        # cases for calculator

        if operationInput == 1:

            print(f"{firstNumber} + {secondNumber}")
            result = addTwoNumber(firstNumber, secondNumber)
            print(f"Result : {result}")

        elif operationInput == 2:

            print(f"{firstNumber} - {secondNumber}")
            result = subTwoNumber(firstNumber, secondNumber)
            print(f"Result : {result}")

        elif operationInput == 3:

            print(f"{firstNumber} * {secondNumber}")
            result = mulTwoNumber(firstNumber, secondNumber)
            print(f"Result : {result}")

        elif operationInput == 4:

            print(f"{firstNumber} // {secondNumber}")
            result = divTwoNumber(firstNumber, secondNumber)
            print(f"Result : {result}")






# main function
def main():

    # exception handling for calculator
    try:
        calculator()

    except IOError as error:

        print("Exception occured ! Invalid Input")

    except Exception as e :

        print("Exception occured : "+str(e))

    finally :

        print("Try catch for calculator finished")

# driver
if __name__ == "__main__":

    main()