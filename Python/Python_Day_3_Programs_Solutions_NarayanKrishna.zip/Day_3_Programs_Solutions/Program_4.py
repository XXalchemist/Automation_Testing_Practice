"""
Program 4: Create a class name Student having name and email as attributes. Create a function named printDetails() which will print name and email details.
Also create 3 department class which inherits from Student Class and names of classes will be Technology, Medicine and Hospitality.
Add below attributes in child classes.
Department name, Course, roll number, joining year.
Create printDetails function in child classes and override parent method and print below details.
Name,email,Department name, Course, roll number, joining year

"""

# class student
class Student:

    def __init__(self, name, email):

        self.name = name
        self.email = email

    # print email and name
    def printDetails(self):

        print("-------------------------------- Student Details ------------------------------------")

        print(f"Name : {self.name}")
        print(f"email: {self.email}")

        print("--------------------------------------------------------------------------------------")

# class Technology - att. departmentName, course, rollNumber, joiningYear ; method. printDetails()
class Technology(Student):

    departmentName = "Techonology"

    def __init__(self, name, email, course, rollNumber, joiningYear):

        # calling parent class
        Student.__init__(self, name, email)

        # department attributes
        self.course = course
        self.rollNumber = rollNumber
        self.joiningYear = joiningYear

    # Method Override for printDetails()
    def printDetails(self):
        print("-------------------------------- Department Details ------------------------------------")

        print(f"Name : {self.name}")
        print(f"email: {self.email}")

        print(f"Department Name : {Technology.departmentName}")
        print(f"Course: {self.course}")
        print(f"RollNumber: {self.rollNumber}")
        print(f"Joining Year: {self.joiningYear}")

        print("----------------------------------------------------------------------------------------")

# class Medicine
class Medicine(Student):

    departmentName = "Medicine"

    def __init__(self, name, email, course, rollNumber, joiningYear):

        Student.__init__(self, name, email)

        # department attributes
        self.course = course
        self.rollNumber = rollNumber
        self.joiningYear = joiningYear

    # Method Override for printDetails()
    def printDetails(self):
        print("-------------------------------- Department Details ------------------------------------")

        print(f"Name : {self.name}")
        print(f"email: {self.email}")

        print(f"Department Name : {Medicine.departmentName}")
        print(f"Course: {self.course}")
        print(f"RollNumber: {self.rollNumber}")
        print(f"Joining Year: {self.joiningYear}")

        print("----------------------------------------------------------------------------------------")


# class Hospitality
class Hospitality(Student):

    departmentName = "Hospitality"
    def __init__(self, name, email, course, rollNumber, joiningYear):

        Student.__init__(self, name, email)

        # department attributes
        self.course = course
        self.rollNumber = rollNumber
        self.joiningYear = joiningYear

    # Method Override for printDetails()
    def printDetails(self):
        print("-------------------------------- Department Details ------------------------------------")

        print(f"Name : {self.name}")
        print(f"email: {self.email}")

        print(f"Department Name : {Hospitality.departmentName}")
        print(f"Course: {self.course}")
        print(f"RollNumber: {self.rollNumber}")
        print(f"Joining Year: {self.joiningYear}")

        print("----------------------------------------------------------------------------------------")


# main function
def main():

    student1 = Student("Narayan","email@gmail.com")
    student1.printDetails()

    # inheriting to 3 different dept. child classes

    # Techonology - python
    student1 = Technology("Narayan","email@gmail.com","Python","0000001","2021")
    student1.printDetails()

    # Medicine - Viruses
    student1 = Medicine("Narayan","email@gmail.com","Viruses", "0000001", "2021")
    student1.printDetails()

    # Hospitality - Cabin crew
    student1 = Hospitality("Narayan","email@gmail.com","Cabin Crew", "0000001", "2021")
    student1.printDetails()


# driver
if __name__ == "__main__":

    main()



