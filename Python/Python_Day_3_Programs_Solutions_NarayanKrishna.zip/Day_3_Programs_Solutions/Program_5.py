""""
Problem 5: In continuation to problem 4, create a program to ask user to create a Student and ask all attributes
and add created student to a list and keep on asking to create more students until user quits.
For.e.g. show below message
Welcome to Add Student Console.
1-	Add Student
2-	Quit
When user quits just print number of students added in list and call printDetails() for each student.

"""

# importing required modules
import Program_4

# Show console menu
def showMenu():

    print(""""Welcome to Add Student Console.
            1-	Add Student
            2-	Quit
            """)

# add menu
def addStudent(studentData):

    # getting inputs
    studentName = input("Enter student name : ")
    studentEmail = input("Enter student email : ")
    studentJoiningYear = input("Enter the joining year : ")
    studentRollNumber = input("Enter the roll number : ")

    studentCourse = input("Enter course name : ")
    studentDepartment = input("Enter department name (Technology, Medicine, Hospitality): ")

    if(studentDepartment.lower() == 'technology'):

        student = Program_4.Technology(studentName, studentEmail, studentCourse, studentRollNumber, studentJoiningYear)

    elif(studentDepartment.lower() == 'medicine'):

        student = Program_4.Medicine(studentName, studentEmail, studentCourse, studentRollNumber, studentJoiningYear)

    elif(studentDepartment.lower() == 'hospitality'):

        student = Program_4.Hospitality(studentName, studentEmail, studentCourse, studentRollNumber, studentJoiningYear)

    else :

        print("Invalid Department")


    # storing data
    studentData.append(student)

# use list ot store student data
def main():

    # lsit to store all student data
    studentData = []

    while(True):

        showMenu()
        choice = int(input("Enter your choice : "))

        if(choice == 1):

            addStudent(studentData)

        elif(choice == 2):

            # if record is empty
            if(len(studentData) == 0):

                print("Empty Record")
                quit()

            # show data and quit
            print("------------------------------- Student Data -------------------------------------------------")
            print("Total Number of students : "+str(len(studentData)))
            for student in studentData:
                student.printDetails()

            quit()

        else :

            print("Not a valid Input")


# driver
if __name__ == "__main__":

    main()