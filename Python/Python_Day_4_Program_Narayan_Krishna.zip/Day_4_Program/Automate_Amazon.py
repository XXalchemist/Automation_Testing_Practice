"""
Pre-requisites:
•	Do selenium setup using pip install selenium and make sure setup is fine.
•	Download chromedriver/geckodriver as per chrome/firefox versions on your system (priority will be chrome)

Assignment:
•	Use https://www.amazon.in
•	On search bar type “mobiles” and search
•	After that print number of search results returned on the page (only first page)
•	Also print name of the products returned on the page (only first page)
•	Output of code will be like below.

We are getting 22 search results which are listed below:
Samsung Galaxy M51 (Electric Blue, 8GB RAM, 128GB Storage)
OnePlus 8T 5G (Lunar Silver, 8GB RAM, 128GB Storage)
Samsung Galaxy M31 (Ocean Blue, 6GB RAM, 128GB Storage)
Samsung Galaxy M21 (Midnight Blue, 4GB RAM, 64GB Storage)
"""

# import
from selenium import webdriver

# location of drivers
from selenium.webdriver.common.by import By

chrome_driver_location = "./Drivers/chromedriver.exe"
firefox_driver_location = "./Drivers/geckodriver.exe"

# website
website_url = "https://www.amazon.in"

# search query
search_query = "mobiles"

# global driver
# driver = webdriver

# creating a method for future use
def open_browser(browser):
    if browser.lower() == "chrome":
        driver = webdriver.Chrome(chrome_driver_location)
        driver.maximize_window()
        return driver
    elif browser.lower() == "firefox":
        driver = webdriver.Chrome(firefox_driver_location)
        driver.maximize_window()
        return driver
    else:
        raise Exception("Browser not supported. Suggested values are [Chrome,Firefox]")


# open webpage
def open_url(driver, website_url):
        driver.get(website_url)


# searching function
def search_amazon(driver, search_query):
    # element for search input and search button
    # searchBox element
    searchBox = driver.find_element_by_id("twotabsearchtextbox")

    # searchButton element
    searchButton = driver.find_element_by_id("nav-search-submit-button")

    # flow
    searchBox.clear()
    searchBox.send_keys(search_query)
    searchButton.click()

# show the result
def show_total_elements_on_first_page(driver):

    # Locating all searched Elements
    # searched_elements = driver.find_elements(By.XPATH, '//div[@data-component-type = "s-search-result"]')

    searched_elements = driver.find_elements(By.XPATH, '//*[@class = "a-size-medium a-color-base a-text-normal"]')
    total_elements = len(searched_elements)
    index = 1

    # show total length
    print(f"We are getting {str(total_elements)} search results which are listed below:")

    # show the result
    for element in searched_elements:
        print(f"{index}. {element.text}")
        index = index + 1


# close
def close_url(driver):
    driver.quit()
    driver.close()

# main function
def main():

    try:
        browser_name = input("Choose from Chrome or Firefox : ")
        driver = open_browser(browser_name)

        # open url
        open_url(driver,website_url)

        # search for mobiles
        search_amazon(driver, search_query)

        # count total searched elements on first page and return the title of all that product
        show_total_elements_on_first_page(driver)

        # close the browser
        close_url(driver)

    except Exception as e:
        print(e)

# init function
if __name__ == "__main__":
    main()