package com.Nagarro.RestApi.Tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import com.Nagarro.RestApi.Utils.Utils;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;;

public class BaseTest {
	
	// Initializing the data.properties and Log4j
	public static Properties prop = new Properties();
	public static File file = new File("./Resources/props/data.properties");
	public static FileInputStream fis = null;
	public final static Logger logger = Logger.getLogger(BaseTest.class);
	
	
	static { 
		
		// Exception Handling for FIS
		try {
			
			fis = new FileInputStream(file);
		}catch(FileNotFoundException e){
			
			System.out.println(e.getMessage());
		}
		
		// Exception Handling for Prop
		try {
			
			prop.load(fis);
		}catch(IOException e) {
			
			System.out.println(e.getMessage());
		}
		
	}
	
	@BeforeTest
	public void setup() {
		
		
		// Setting up the baseURI
		RestAssured.baseURI = prop.getProperty("baseURI");
	}
	
	@BeforeMethod
	public void init() {
		
		logger.info("--- Test Started ---\n");
		System.out.println("--- Test Started ---\n");
		
	}
	
	
	@AfterMethod
	public void tearDown() {
		
		logger.info("--- Test Completed ---\n");
		
		System.out.println("--- Test Completed ---\n");
	}
		
}
