package com.Nagarro.RestApi.Tests;

import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Nagarro.RestApi.Utils.TestHelper;
import com.Nagarro.RestApi.Utils.Utils;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

// Test cases for Boards
public class BoardTest extends BaseTest {

	// POST - Valid Create Board
	@Test
	public void ValidCreateBoard() {

		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken()).queryParam("name", prop.getProperty("expectedBoardName")).log().all()
				.post(prop.getProperty("boardResource"));

		JsonPath responseJson = Utils.rawToJson(response);

		String actualBoardName = responseJson.get("name");
		String boardId = responseJson.getString("id");

		// Assertion for Board Name
		Assert.assertEquals(actualBoardName, prop.getProperty("expectedBoardName"),
				"Verify actual BoardName == expected BoardName");
		
		// Deleting the created board
		TestHelper.DeleteBoard(boardId);

		logger.info("---- Valid Create Board Test Completed---- ");
	}

	// GET - Valid Get Board
	@Test
	public void ValidGetBoard() {
		
		// Create a dummy board for testing
		TestHelper.CreateBoard();
		
		String currentBoardId = Utils.getCurrentBoardId();

		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();

		Response response = httpRequest.when().header("Accept", "application/json")
				.queryParams(Utils.UpdatingKeyAndToken()).log().all()
				.get(prop.getProperty("boardResource") + currentBoardId);

		JsonPath responseJson = Utils.rawToJson(response);

		String actualBoardName = responseJson.get("name");

		// Assertion for Board Name
		Assert.assertEquals(actualBoardName, prop.getProperty("expectedBoardName"),
				"Verify actual BoardName == expected BoardName");
		
		// Deleting a dummy board
		TestHelper.DeleteBoard(currentBoardId);
		
		logger.info("---- Valid Get Board Test Complete ---- ");
	}

	// GET Negative scenario - Invalid Board Id
	@Test
	public void InvalidGetBoard() {
		
		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();

		Response response = httpRequest.when().header("Accept", "application/json")
				.queryParams(Utils.UpdatingKeyAndToken()).log().all()
				.get(prop.getProperty("boardResource") + prop.getProperty("invalidBoardId"));

		int actualStatusCode = response.getStatusCode();

		// Assertion for Status Code
		Assert.assertEquals(actualStatusCode, Integer.parseInt(prop.getProperty("expectedPNFStatusCode")),
				"Verify actual StatusCode == expected StatusCode");

		logger.info("Invalid Get Board Test Completed");
	}

	// PUT - Valid Update the name of board
	@Test
	public void ValidUpdateBoard() {
		
		// Create a dummy board for testing
		TestHelper.CreateBoard();
				
		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken()).queryParam("name", prop.getProperty("newBoardName")).log().all()
				.put(prop.getProperty("boardResource") + Utils.getCurrentBoardId());

		JsonPath responseJson = Utils.rawToJson(response);

		String actualBoardName = responseJson.get("name");

		String currentBoardId = responseJson.getString("id");

		Utils.setCurrentBoardId(currentBoardId);

		// Assertion for Board Name
		Assert.assertEquals(actualBoardName, prop.getProperty("newBoardName"),
				"Verify actual BoardName == expected BoardName");

		logger.info("Valid Update Board Test Completed");
		System.out.println("Board Updated ...");

		Utils.ShowBoardDetails(actualBoardName);
		
		// Delete a dummy board for testing
		TestHelper.DeleteBoard(currentBoardId);
	}

	// DELETE - Valid Delete a board
	@Test
	public void ValidDeleteBoard() {

		// Create a dummy board for testing
		TestHelper.CreateBoard();
		
		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken()).log().all()
				.delete(prop.getProperty("boardResource") + Utils.getCurrentBoardId());

		int actualStatusCode = response.getStatusCode();

		// Assertion for StatusCode
		Assert.assertEquals(actualStatusCode, Integer.parseInt(prop.getProperty("expectedSuccessStatusCode")),
				"Verify actual StatusCode == expected StatusCode");

		logger.info("Valid Delete Board Test Completed");
	}
}
