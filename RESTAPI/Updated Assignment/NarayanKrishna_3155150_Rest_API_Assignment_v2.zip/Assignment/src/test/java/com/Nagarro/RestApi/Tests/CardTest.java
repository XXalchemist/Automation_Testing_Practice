package com.Nagarro.RestApi.Tests;

import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.Nagarro.RestApi.Utils.TestHelper;
import com.Nagarro.RestApi.Utils.Utils;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CardTest extends BaseTest {

	// Creating and deleting board for Test case
	@BeforeClass
	public void CreateNewBoard() {

		TestHelper.CreateBoard();

		// Creating List as Card are added only in List
		TestHelper.CreateList();
	}

	@AfterClass
	public void DeleteNewBoard() {

		TestHelper.DeleteBoard(Utils.getCurrentBoardId());
	}

	// POST - Valid create a new card on board
	@Test
	public void ValidCreateCard() {

		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken()).queryParam("idList", Utils.getCurrentListId())
				.queryParam("name", prop.getProperty("expectedCardName")).log().all()
				.post(prop.getProperty("cardResource"));

		JsonPath responseJson = Utils.rawToJson(response);

		String actualCardName = responseJson.get("name");

		String currentCardId = responseJson.get("id");

		Utils.setCurrentCardId(currentCardId);

		// Assertion for Card Name
		Assert.assertEquals(actualCardName, prop.getProperty("expectedCardName"),
				"Verify actual CardName == expected CardName");

		logger.info("Valid Create Card Test Completed");
	}

	// GET - Valid get a card
	@Test
	public void ValidGetCard() {

		// Create a New Card
		TestHelper.CreateCard();

		String currentCardId = Utils.getCurrentCardId();

		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json")
				.queryParams(Utils.UpdatingKeyAndToken()).log().all()
				.get(prop.getProperty("cardResource") + currentCardId);

		JsonPath responseJson = Utils.rawToJson(response);

		String actualCardName = responseJson.get("name");

		// Assertion for Card Name
		Assert.assertEquals(actualCardName, prop.getProperty("expectedCardName"),
				"Verify actual CardName == expected CardName");

		logger.info("Valid Get Card Test Completed");
	}

	// GET - Invalid card id
	@Test
	public void InvalidGetCard() {

		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json")
				.queryParams(Utils.UpdatingKeyAndToken()).log().all()
				.get(prop.getProperty("cardResource") + prop.getProperty("InvalidCardId"));

		int actualStatusCode = response.getStatusCode();

		// Assertion for Status Code
		Assert.assertEquals(actualStatusCode, Integer.parseInt(prop.getProperty("expectedPNFStatusCode")),
				"Verify actual StatusCode == expected StatusCode");

		logger.info("Invalid Get Card Test Completed");
	}

	// PUT - Valid update a card
	@Test
	public void ValidUpdateCard() {

		// Create a New Card
		TestHelper.CreateCard();

		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken()).queryParam("idList", Utils.getCurrentListId())
				.queryParam("name", prop.getProperty("newCardName")).log().all().post(prop.getProperty("cardResource"));

		JsonPath responseJson = Utils.rawToJson(response);

		String actualCardName = responseJson.get("name");

		String currentCardId = responseJson.get("id");

		Utils.setCurrentCardId(currentCardId);

		// Assertion for Card Name
		Assert.assertEquals(actualCardName, prop.getProperty("newCardName"),
				"Verify actual CardName == expected CardName");

		logger.info("Valid Update Card Test Completed");
	}

	// DELETE - Valid delete a card
	@Test
	public void ValidDeleteCard() {

		// Create a New Card
		TestHelper.CreateCard();

		String currentCardId = Utils.getCurrentCardId();

		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json")
				.queryParams(Utils.UpdatingKeyAndToken()).log().all()
				.delete(prop.getProperty("cardResource") + currentCardId);

		int actualStatusCode = response.getStatusCode();

		// Assertion for Status Code
		Assert.assertEquals(actualStatusCode, Integer.parseInt(prop.getProperty("expectedSuccessStatusCode")),
				"Verify actual StatusCode == expected StatusCode");

		logger.info("Valid Delete Card Test Completed");
	}

}
