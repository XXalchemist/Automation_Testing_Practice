package com.Nagarro.RestApi.Tests;

import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.Nagarro.RestApi.Utils.TestHelper;
import com.Nagarro.RestApi.Utils.Utils;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ListTest extends BaseTest {

	// Creating and Deleting new board
	@BeforeClass
	public void CreateNewBoard() {
		
		TestHelper.CreateBoard();
	}
	
	@AfterClass
	public void DeleteNewBoard() {
		
		TestHelper.DeleteBoard(Utils.getCurrentBoardId());
	}
	
	// POST - Create a valid List on given board
	@Test
	public void ValidCreateList() {
		
	
		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken())
				.queryParam("name", prop.getProperty("expectedListName"))
				.queryParam("idBoard", Utils.getCurrentBoardId())
				.log().all().post(prop.getProperty("listResource"));

		JsonPath responseJson = Utils.rawToJson(response);

		String actualListName = responseJson.get("name");

		String currentListId = responseJson.getString("id");

		Utils.setCurrentListId(currentListId);

		// Assertion for Board Name
		Assert.assertEquals(actualListName, prop.getProperty("expectedListName"),
				"Verify actual ListName == expected ListName");

		logger.info("Valid Create List Test Completed");
	}

	// GET - Get a valid List
	@Test
	public void ValidGetList() {
		
		// Creating a new List
		TestHelper.CreateList();

		String currentListId = Utils.getCurrentListId();

		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken())
				.queryParam("idBoard",Utils.getCurrentBoardId())
				.log().all().get(prop.getProperty("listResource") + currentListId);

		JsonPath responseJson = Utils.rawToJson(response);

		String actualListName = responseJson.get("name");

		// Assertion for Board Name
		Assert.assertEquals(actualListName, prop.getProperty("expectedListName"),
				"Verify actual ListName == expected ListName");

		logger.info("Valid Get List Test Completed");
	}

	// GET - Negative scenario - Invalid Get List
	@Test
	public void InvalidGetList() {

		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken())
				.queryParam("idBoard",Utils.getCurrentBoardId())
				.log().all().get(prop.getProperty("listResource") + prop.getProperty("invalidListId"));

		int actualStatusCode = response.getStatusCode();

		// Assertion for Status Code
		Assert.assertEquals(actualStatusCode, Integer.parseInt(prop.getProperty("expectedPNFStatusCode")),
				"Verify actual StatusCode == expected StatusCode");

		logger.info("Invalid Get List Test Completed");
	}

	// PUT - Update the name of the List
	@Test
	public void ValidUpdateList() {
		
		// Creating a new list
		TestHelper.CreateList();
		
		String currentListId = Utils.getCurrentListId();

		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken())
				.queryParam("name", prop.getProperty("newListName"))
				.log().all().put(prop.getProperty("listResource") + currentListId);

		JsonPath responseJson = Utils.rawToJson(response);

		String actualListName = responseJson.get("name");

		Utils.setCurrentListId(currentListId);

		// Assertion for Board Name
		Assert.assertEquals(actualListName, prop.getProperty("newListName"),
				"Verify actual ListName == expected ListName");

		logger.info("Valid Update List Test Completed");
	}

	// PUT - Archive the List
	@Test
	public void ValidArchiveAllCards() {
		
		// Creating a new list
		TestHelper.CreateList();
		
		String currentListId = Utils.getCurrentListId();


		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken())
				.log().all().post(prop.getProperty("listResource") + currentListId + "/archiveAllCards");

		int actualStatusCode = response.getStatusCode();

		// Assertion for Status Code
		Assert.assertEquals(actualStatusCode, Integer.parseInt(prop.getProperty("expectedSuccessStatusCode")),
				"Verify actual StatusCode == expected StatusCode");

		logger.info("Valid Archive List Test Completed");
	}

}
