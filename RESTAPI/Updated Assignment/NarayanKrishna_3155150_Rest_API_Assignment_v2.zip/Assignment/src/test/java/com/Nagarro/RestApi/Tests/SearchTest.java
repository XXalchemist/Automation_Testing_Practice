package com.Nagarro.RestApi.Tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.Nagarro.RestApi.Utils.TestHelper;
import com.Nagarro.RestApi.Utils.Utils;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class SearchTest extends BaseTest {

	// Before and After is used to create and delete the board
	
	@BeforeClass
	public void CreateNewBoard() {
		
		TestHelper.CreateBoard();
	}
	
	@AfterClass
	public void DeleteNewBoard() {
		
		TestHelper.DeleteBoard(Utils.getCurrentBoardId());
	}
	
	// GET - Valid Search
	@Test
	public void ValidBoardSearch() {

		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken())
				.queryParam("query", prop.getProperty("expectedSearchBoardName"))
				.log().all().get(prop.getProperty("searchResource"));

		JsonPath responseJson = Utils.rawToJson(response);

		ArrayList actualSearchedItems = responseJson.get("boards");

		// Fetching name of first searched board
		Map<String, String> actualBoardNames = (Map<String, String>) actualSearchedItems.get(0);

		String actualBoardName = actualBoardNames.get("name");

		// Assertion for Board Name
		Assert.assertEquals(actualBoardName, prop.getProperty("expectedSearchBoardName"),
				"Verify actual SearchBoardName == expectedSearchBoardName");

		logger.info("Valid Search Test Completed");

	}

	// GET - When there is nothing to search
	@Test
	public void InvalidBoardSearch() {

		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken())
				.queryParam("query", prop.getProperty("invalidSearchBoardName"))
				.log().all().get(prop.getProperty("searchResource"));

		JsonPath responseJson = Utils.rawToJson(response);

		// Fetching name of first searched board

		try {
			
			ArrayList actualSearchedItems = responseJson.get("boards");
			Map<String, String> actualBoardNames = (Map<String, String>) actualSearchedItems.get(0);
			String actualBoardName = actualBoardNames.get("name");
		}

		catch (Exception e) {

			String actualBoardName = "";

			// Assertion for Board Name

			Assert.assertEquals(actualBoardName, prop.getProperty("expectedInvalidSearchBoardData"),
					"Verify actual SearchBoardData == expectedSearchData");

			logger.info("Invalid Search Test Completed");
		}
	}
}
