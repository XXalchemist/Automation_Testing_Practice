package com.Nagarro.RestApi.Utils;

import com.Nagarro.RestApi.Tests.BaseTest;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TestHelper extends BaseTest {

	// Helpers Method For Test

	// Before Class Method - Board Creation
	public static void CreateBoard() {

		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken()).queryParam("name", prop.getProperty("expectedBoardName"))
				.post(prop.getProperty("boardResource"));

		JsonPath responseJson = Utils.rawToJson(response);

		// Setting up board name and id so that it can be used later
		String boardName = responseJson.get("name");
		Utils.setCurrentBoardName(boardName);

		String currentBoardId = responseJson.getString("id");
		Utils.setCurrentBoardId(currentBoardId);

		logger.info("---- Default Board Created ---- ");

		Utils.ShowBoardDetails(Utils.getCurrentBoardName());

	}

	// After Class Method - Board Deletion
	public static void DeleteBoard(String id) {

		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken()).delete(prop.getProperty("boardResource") + id);

		Utils.setCurrentBoardId("");
		
		logger.info("Delete TestBoard Completed");

		System.out.println("--- Default Board Deleted ---");	

	}
	
	// Creating a List
	public static void CreateList() {
		
		// Creating Request
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken())
				.queryParam("name", prop.getProperty("expectedListName"))
				.queryParam("idBoard", Utils.getCurrentBoardId())
				.post(prop.getProperty("listResource"));

		JsonPath responseJson = Utils.rawToJson(response);

		String currentListId = responseJson.getString("id");

		Utils.setCurrentListId(currentListId);
		
		System.out.println("--- List Created ---");
	}
	
	// Creating a card
	public static void CreateCard() {
		
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.when().header("Accept", "application/json").body("")
				.queryParams(Utils.UpdatingKeyAndToken())
				.queryParam("idList", Utils.getCurrentListId())
				.queryParam("name",prop.getProperty("expectedCardName"))
				.post(prop.getProperty("cardResource"));

		JsonPath responseJson = Utils.rawToJson(response);

		String actualCardName = responseJson.get("name");

		String currentCardId = responseJson.get("id");

		Utils.setCurrentCardId(currentCardId);
		
		System.out.println("--- Card Created ---");
	}
}
