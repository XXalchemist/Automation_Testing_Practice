package com.Nagarro.RestApi.Utils;

import java.util.HashMap;
import java.util.Map;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Utils {

	private static String currentBoardId = "";
	private static String currentBoardName = "";

	private final static String token = "bc58afd6314911e751d1646dbe4d1e2474018b7216f02981f76a8742ab79b6c9";
	private final static String userName = "Narayan Krishna";
	private final static String apiKey = "a39f924fe0dda168289470b335d7d2e0";

	private static String currentCardId = "";
	private static String currentListId = "";

	public static String getApiKey() {
		return apiKey;
	}

	public static String getToken() {
		return token;
	}

	public static String getCurrentBoardId() {
		return currentBoardId;
	}

	public static void setCurrentBoardId(String currentBoardId) {
		Utils.currentBoardId = currentBoardId;
	}

	public static String getUserName() {
		return userName;
	}


	public static JsonPath rawToJson(Response response) {

		String responseString = (response).asString();
		JsonPath responseJson = new JsonPath(responseString);
		return responseJson;
	}

	public static String getCurrentCardId() {
		return currentCardId;
	}

	public static void setCurrentCardId(String currentCardId) {
		Utils.currentCardId = currentCardId;
	}

	public static String getCurrentListId() {
		return currentListId;
	}

	public static void setCurrentListId(String currentListId) {
		Utils.currentListId = currentListId;
	}

	public static String getCurrentBoardName() {
		return currentBoardName;
	}

	public static void setCurrentBoardName(String currentBoardName) {
		Utils.currentBoardName = currentBoardName;
	}

	// Methods to update key and token
	public static Map<String, String> UpdatingKeyAndToken() {

		Map<String, String> data = new HashMap<String, String>();

		data.put("key", Utils.getApiKey());
		data.put("token", Utils.getToken());

		return data;
	}

	// Showing board Detail
	public static void ShowBoardDetails(String boardName) {
		
		System.out.println("--- Board Detail ---");
		System.out.println("Board Name : " + boardName);
		System.out.println("Board Id : " + Utils.getCurrentBoardId());
		System.out.println("---    ---       ---");
	}

}
