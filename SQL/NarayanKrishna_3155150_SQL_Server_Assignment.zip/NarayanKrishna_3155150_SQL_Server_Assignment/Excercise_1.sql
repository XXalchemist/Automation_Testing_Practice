/* Excercise - 1 */

--- Question - 1 : Display the number of records in the [SalesPerson] table. (Schema(s) involved: Sales) ---

USE AdventureWorks2014;

SELECT COUNT(*)
FROM Sales.SalesPerson;

--- Question - 2 : Select both the FirstName and LastName of records from the Person table where the FirstName begins with the letter �B�. (Schema(s) involved: Person) ---

SELECT FirstName, LastName
FROM Person.Person
WHERE FirstName LIKE 'B%';

--- Question - 3 : Display the Name and Color of the Product with the maximum weight. (Schema(s) involved: Production) ---

SELECT Name , Color
FROM Production.Product
WHERE Weight = (
	SELECT MAX(Weight)
	FROM Production.Product
	);

--- Question - 4 : Display Description and MaxQty fields from the SpecialOffer table. Some of the MaxQty values are NULL, in this case display the value 0.00 instead. (Schema(s) involved: Sales) ---

SELECT Description, ISNULL(MaxQty, 0.00)
FROM Sales.SpecialOffer;

--- Question - 5 : Display the overall Average of the [CurrencyRate].[AverageRate] values for the exchange rate �USD� to �GBP� for the year 2011 i.e. FromCurrencyCode = �USD� and ToCurrencyCode = �GBP�. Note: The field [CurrencyRate].[AverageRate] is defined as 'Average exchange rate for the day.' (Schema(s) involved: Sales) ---

SELECT AVG(AverageRate)
FROM Sales.CurrencyRate
WHERE YEAR(CurrencyRateDate) = 2011
AND
FromCurrencyCode = 'USD' AND ToCurrencyCode = 'GBP';

-- To Check ---
SELECT CurrencyRateDate, AverageRate, FromCurrencyCode, ToCurrencyCode From Sales.CurrencyRate WHERE FromCurrencyCode = 'USD' AND ToCurrencyCode = 'GBP' AND YEAR(CurrencyRateDate)  = 2011 ;

--- Question - 6 : Display the FirstName and LastName of records from the Person table where FirstName contains the letters �ss�. Display an additional column with sequential numbers for each row returned beginning at integer 1. (Schema(s) involved: Person) --- 

SELECT FirstName, LastName, ROW_NUMBER() Over (Order by (SELECT Null)) As SequentialID
FROM Person.Person
WHERE FirstName LIKE '%ss%';

--- Question - 7 : Display the [SalesPersonID] with an additional column entitled �Commission Band� indicating the appropriate band as above. [Hint : Use Temp table] [BusinessEntityD] ---


SELECT BusinessEntityID AS SalesPersonID, CommissionPct, 
'Commission Band'= 
CASE
	WHEN CommissionPct = 0 THEN 'Band 0'
	WHEN CommissionPct > 0 AND CommissionPct <= 0.01 THEN 'Band 1'
	WHEN CommissionPct > 0.01 AND CommissionPct <= 0.015 THEN 'Band 2'
	WHEN CommissionPct > 0.015 THEN 'Band 3'
END
FROM Sales.SalesPerson
ORDER BY CommissionPct;


--- Question - 8 : Display the ProductId of the product with the largest stock level. Hint: Use the Scalar-valued function [dbo]. [UfnGetStock]. (Schema(s) involved: Production). ---

SELECT ProductId
FROM Production.Product
WHERE dbo.ufnGetStock(ProductId) = (
SELECT MAX(dbo.ufnGetStock(ProductID))
FROM Production.Product);

--- To validate the answer ---
SELECT MAX(dbo.ufnGetStock(ProductId))
FROM Production.Product;

SELECT ProductId, dbo.ufnGetStock(ProductId)
FROM Production.Product
WHERE ProductID = 528;
---

/* End of Excercise - 1 */