/* Excercise - 2*/

--- Show the most recent five orders that were purchased from account numbers that have spent more than $70,000 with AdventureWorks. ---

USE AdventureWorks2014;

--- We can use sales table ---
--- Shows Total Due Also ... So that it can be verified ---

SELECT TOP (5) AccountNumber, OrderDate, SS.TotalDue
FROM Sales.SalesOrderHeader AS SS 
WHERE SS.TotalDue > 70000
AND SS.AccountNumber IN (SELECT TOP(5) SS.AccountNumber
                FROM Sales.SalesOrderDetail As SO
                JOIN Sales.SalesOrderHeader
                ON SO.SalesOrderID = SS.SalesOrderID
                HAVING SUM(SO.LineTotal) > 70000
				) 
				GROUP BY SS.TotalDue, SS.AccountNumber, OrderDate 
				ORDER BY OrderDate DESC;
