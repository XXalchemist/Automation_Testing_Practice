/* Excercise - 3 */

--- Create a stored procedure that accepts the name of a product and display its ID, number, and availability. (Use the AdventureWorks database) ---

CREATE PROCEDURE spGetProductIdNumberAndAvailabilityByProductName
@ProductName VARCHAR(50)
AS
BEGIN

SELECT ProductId, ProductNumber , MakeFlag AS Availability
FROM Production.Product
WHERE Product.Name = @ProductName

END;


EXEC spGetProductIdNumberAndAvailabilityByProductName 'Adjustable Race';

--- Testing ---
Select Name, MakeFlag from  Production.Product WHERE Name = 'Adjustable Race';
