/* Excercise - 4 */

--- Create a trigger to ensure that the average of the values in the Rate column of the EmployeePayHistory table should not be more than 20 when the value of the rate is increased. (Use the AdventureWorks database) ---
/* Use AdventureWorks2014; */

CREATE TRIGGER tr_AverageRateValueShouldNotMoreThan20WhenTheValueIsIncreased 
ON HumanResources.EmployeePayHistory
FOR UPDATE
AS 
IF UPDATE(Rate)
BEGIN
	DECLARE @AvgRate FLOAT
	SELECT @AvgRate = AVG(Rate)
	FROM HumanResources.EmployeePayHistory
	IF (@avgRate>20)
		BEGIN
		Print 'ERROR ! Average value of the rate is not more than 20'
		Rollback Transaction
		END
END;

--- Testing ---
UPDATE HumanResources.EmployeePayHistory SET RATE = 21 ;
