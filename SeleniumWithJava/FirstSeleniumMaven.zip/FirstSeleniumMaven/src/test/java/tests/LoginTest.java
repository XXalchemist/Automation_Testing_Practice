package tests;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import pages.LoginPage;

public class LoginTest extends BaseTest {

	@Test(groups= {"validlogin"},priority=1)
	@Parameters({"validUsername","password"})
	public void validLogin(String username, String password) throws InterruptedException {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterUsername(username);
		loginPage.enterPassword(password);
		loginPage.clickSubmit();
		Thread.sleep(5000);
		// Assert.assertEquals(driver.getTitle(), "Login:Merucry Tours");
		Assert.assertTrue(driver.getTitle().contains("Login"));
	}

	@Test(groups= {"invalidlogin"}, priority=2)
	@Parameters({"invalidUsername","password"})
	public void invalidLoginUsername(String username, String password) throws InterruptedException {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterUsername(username);
		loginPage.enterPassword(password);
		loginPage.clickSubmit();
		Thread.sleep(5000);
		Assert.assertTrue(driver.getTitle().contains("Welcome"));
	}
	

}
