# Selenium Assignment

** Objective :- **

1. Make Maven Project for the assignment.

2. Open link http://automationpractice.com/index.php    

3. Implement Page object model framework

4. Test Data should be read from properties  file.

5. Test configurations like – application url, browser name, global wait time should be read from properties file.

6. Implement proper waits.

7. Implement assertions

8. Implement extent report, put proper assertions with error description in the report. 
   If any test cases fails take a screenshot with the name same as test case and appended by a brief description of error in the screenshot file name (For e.g. TestCase1_Invalid_Credentials)

9. Minimum 5 scenarios to be implemented 
   
- Below three mandatory passing test cases/scenarios :-
   
   a) Registration of a user.
   
   b) Login of a user.
   
   c) Hovering over Women's link,Click on sub menu 'T-shirts'.
    
	- Get Name/Text of the first product displayed on the page
	- Now enter the same product name in the search bar present on top of page and click search button
	- Validate that same product is displayed on searched page with same details which were displayed on T-Shirt's page.
	- And any two failing test cases/scenarios

> Should have minimum two test classes and atleast two page files. Logger implemention would get a bonus point.

**Note :** 

Please try to take care of following features in the framework –	

Coding guidelines
	
Modularity, Reusability, Readability

---