# Selenium Assignment


_Open objective.md for the detail about the assignment._

> How to run project :-

- Extract Project into your directory.
- open cmd in the project directory.
- run following command.

```
mvn clean
mvn install

```

- Wait for the test to complete.

> Path For important files :-

- extent Report : ./resources/ ReportGenerated.html
- configuration.properties : ./resources/prop/configuration.properties
- google and firefox drivers : ./resources/drivers/
- log4j.properties : ./src/main/resources/log4j.properties
- log file : ./log/log4j-application.log

**IMPORTANT NOTATIONS :-**

- testID_Wn : test cases for Women Page 
- testID_Cn : test cases for Contact Page
- testID_Sn : test cases for Search Page
- testID_Rn : test cases for Register Page
- testID_Ln : test cases for Login Page

> **n** is for test case number.
