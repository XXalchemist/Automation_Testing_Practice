package com.assignment.pages;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ContactUsPage {
	
public WebDriver driver;
	
	public ContactUsPage(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}
	
	// Flow for the login
	
	@FindBy(how = How.LINK_TEXT, using = "Contact us")
	public WebElement contactUs;
	
	// select a heading
	@FindBy(how = How.XPATH, using = "//select[@id='id_contact']")
	public WebElement heading;

	
	// send email
	@FindBy(how = How.XPATH, using = "//input[@id='email']")
	public WebElement email;
	
	// send order reference
	@FindBy(how = How.XPATH, using = "//input[@id='id_order']")
	public WebElement order_id;
	
	// send message
	@FindBy(how = How.XPATH, using = "//textarea[@id='message']")
	public WebElement message;
	
	
	// send
	@FindBy(how = How.XPATH, using = "//button[@id= 'submitMessage']")
	public WebElement sendBtn;
	
	
	public void enterEmail(String mail) {
		
		email.sendKeys(mail);
	}
	
	public void enterOrderId(String id) {
		
		order_id.sendKeys(id);
	}
	
	public void selectHeading(String headingName) {
		
		Select drpDown = new Select(heading);
		drpDown.selectByVisibleText(headingName);
	}
	
	public void clickSend() {
		
		sendBtn.click();
	}
	
	public void enterMessage(String comment) {
		
		message.sendKeys(comment);
	}
	
	public void clickContactUs() {
		
		contactUs.click();
	}
	
	public boolean getSuccessfulLink() throws NoSuchElementException {
		
		try{
			WebElement successfulLink = driver.findElement(By.xpath("//p[contains(text(),'Your message has been successfully sent to our tea')]"));
		}
		catch (Exception e) {
			return false;
		}
		return true;

	}
}
