package com.assignment.pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DressPage {
	
public WebDriver driver;
	
	public DressPage(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
		this.driver = driver;

	}
	
	// Flow for the login - added later on
	
	@FindBy(how = How.XPATH, using = "//header/div[3]/div[1]/div[1]/div[6]/ul[1]/li[2]/a[1]")
	public WebElement dress;
	
	
	@FindBy(how = How.XPATH, using = "//a[@href = 'http://automationpractice.com/index.php?controller=cart&add=1&id_product=3&token=e817bb0705dd58da8db074c69f729fd8']")
	public WebElement add2cart;
	
	
	@FindBy(how = How.XPATH, using = "//img[@src='http://automationpractice.com/img/p/8/8-home_default.jpg']")
	public WebElement firstProduct;
	
	
	@FindBy(how = How.XPATH, using = "//h2/i[@class='icon-ok']")
	public WebElement add2cartPage;
		
	public void clickDress() {
		
		dress.click();
	}
	
	
	public void clickAdd2Cart() {
		
		Actions hoverOnDress = new Actions(driver);
		hoverOnDress.moveToElement(firstProduct).build().perform();
		add2cart.click();
	}
	
	public String checkPage() {
		String text = add2cartPage.getText();
		return text;
	}
	
}
