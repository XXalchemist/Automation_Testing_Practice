package com.assignment.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/* It includes web components of particular page and methods 
 * to access and set the webelements i.e flow of execution 
 * which in this case is getting username , password and login.
 */

public class LoginPage {
	
	public WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
		this.driver = driver;
		clickSignIn();
	}
	
	// Flow for the login
	
	@FindBy(how = How.LINK_TEXT, using = "Sign in")
	public WebElement signIn;
	
	@FindBy(how = How.ID, using = "email")
	public WebElement email;
	
	@FindBy(how = How.ID, using = "passwd")
	public WebElement password;
	
	@FindBy(how = How.ID, using = "SubmitLogin")
	public WebElement logIn;
	
	@FindBy(how = How.LINK_TEXT, using = "Forgot your password?")
	public WebElement forgotPassword;
	
	public void clickSignIn() {
		
		signIn.click();
	}
	
	public void enterEmail(String emailID) {
		
		email.sendKeys(emailID);
	}
	
	public void enterPassword(String pass) {
		
		password.sendKeys(pass);
	}
	
	public void clickForgotPassword() {
		
		forgotPassword.click();
	}
	
	public void clickLogin() {
		
		logIn.click();
	}
}
