package com.assignment.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegisterPage {
	
public WebDriver driver;
	
	public RegisterPage(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
		this.driver = driver;
		clickSignIn();
	}
	
	// Flow for the creating new account
	
	@FindBy(how = How.LINK_TEXT, using = "Sign in")
	public WebElement signIn;
	
	@FindBy(how = How.NAME, using = "email_create")
	public WebElement emailFirstScreen;
	
	@FindBy(how = How.NAME, using = "SubmitCreate")
	public WebElement register;
	
	@FindBy(how = How.NAME, using = "customer_firstname")
	public WebElement firstName;
	
	@FindBy(how = How.NAME, using = "customer_lastname")
	public WebElement lastName;
	
	@FindBy(how = How.ID, using = "passwd")
	public WebElement password;
	
	@FindBy(how = How.NAME, using = "address1")
	public WebElement address;
	
	@FindBy(how = How.NAME, using = "city")
	public WebElement address_city;
	
	@FindBy(how = How.NAME, using = "id_state")
	public WebElement state;
	
	@FindBy(how = How.NAME, using = "postcode")
	public WebElement postCode;
	
	@FindBy(how = How.NAME, using = "id_country")
	public WebElement country;
	
	@FindBy(how = How.NAME, using = "phone_mobile")
	public WebElement phone_mobile;
	
	@FindBy(how = How.NAME, using = "alias")
	public WebElement alias;
	
	@FindBy(how = How.NAME, using = "submitAccount")
	public WebElement createAccount;
	
	
	// First Screen
	public void clickSignIn() {
		
		signIn.click();
	}
	
	public void enterEmail(String emailID) {
		
		emailFirstScreen.sendKeys(emailID);
	}

	public void clickRegister() {
		
		register.click();
	}
	
	// Selection menu
	public void selectMenu(String stateName) {
		
		Select countrySelect = new Select(country);
		countrySelect.selectByVisibleText("United States");
		
		Select stateSelect = new Select(state);
		stateSelect.selectByVisibleText(stateName);
	}
	
	// Second Screen
	public void enterDetails(String firstname, String lastname, String passwordVar, String addressVar, String cityname, String mobile, String addressAlias, String postalCode ) {
		
		firstName.sendKeys(firstname);
		lastName.sendKeys(lastname);
		password.sendKeys(passwordVar);
		address.sendKeys(addressVar);
		postCode.sendKeys(postalCode);
		address_city.sendKeys(cityname);
		phone_mobile.sendKeys(mobile);
		alias.clear();
		alias.sendKeys(addressAlias);
		
	}
	
	
	// To create new account
	public void createNewAccount() {
		
		createAccount.click();
	}
	

}
