package com.assignment.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class SearchSection {
	
	public WebDriver driver;
	public SearchSection(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}
	
	// Flow for the Search
	
	@FindBy(how = How.XPATH, using = "//input[@id='search_query_top']")
	public WebElement searchBox;
	
	@FindBy(how = How.ID_OR_NAME, using = "submit_search")
	public WebElement searchBtn;
	
	
	public void clickSearchBox() {
		
		searchBox.click();
	}
	
	public void enterSearchItem(String itemName) {
		
		searchBox.sendKeys(itemName);;
	}
	
	public void clickSearchBtn() {
		
		searchBtn.click();
	}
	
}
