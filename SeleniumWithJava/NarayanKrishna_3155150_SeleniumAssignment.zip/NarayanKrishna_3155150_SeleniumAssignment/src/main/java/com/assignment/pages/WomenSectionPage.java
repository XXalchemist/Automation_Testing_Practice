package com.assignment.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class WomenSectionPage {
	
public WebDriver driver;
	
	public WomenSectionPage(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
		this.driver = driver;
	
	}
	
	// Flow for the required task
	
	@FindBy(how = How.XPATH, using = "//a[@title='Women']")
	public WebElement womenBtnLink;
	
	// select a Tshirt
	@FindBy(how = How.XPATH, using = "//a[@title = 'T-shirts']")
	public WebElement tshirtLink;
	
	// First Product
	@FindBy(how = How.LINK_TEXT, using = "Faded Short Sleeve T-shirts")
	public WebElement firstProduct;
	
	
	
	// search box
	@FindBy(how = How.XPATH, using = "//input[@id='search_query_top']")
	public WebElement searchBox;
	
	// searchBtn
	@FindBy(how = How.ID_OR_NAME, using = "submit_search")
	public WebElement searchBtn;
	
	
	// hover over the women section
	public void hoverOnWomen() {
		
		Actions hover = new Actions(driver);
		hover.moveToElement(womenBtnLink).build().perform();
	}
	
	// select first product
	public void clickFirstProduct() {
		tshirtLink.click();
	}
	
	// get the name
	public String getNameOfProduct() {
		
		String productName = firstProduct.getText();
		System.out.println("Get the name -- "+productName);
		return productName;
	}
	
	
	// Search
	public void searchProduct(String productName) {
		
		searchBox.sendKeys(productName);
		searchBtn.click();
		
	}
	
	// match both product
	public boolean matchProduct(String productName) {
		
		String initialProduct = productName ;
		String searchedProduct = driver.findElement(By.linkText("Faded Short Sleeve T-shirts")).getText();
		if (initialProduct.equals(searchedProduct))
			return true;
		else
			return false;
				
	}
}
