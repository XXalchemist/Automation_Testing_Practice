package com.assignment.tests;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseTest {
	
	// To initialize, select(Firefox, Chrome), open and quit browser.
	
	public static WebDriver driver;
	public static Properties prop = new Properties();
	public static File file = new File("./resources/props/configuration.properties");
	public static FileInputStream fis = null;
	public final static Logger logger = Logger.getLogger(BaseTest.class);
	
	// Creating and using properties file
	
	static { 
		
		// Exception Handling for FIS
		try {
			
			fis = new FileInputStream(file);
		}catch(FileNotFoundException e){
			
			System.out.println(e.getMessage());
		}
		
		// Exception Handling for Prop
		try {
			
			prop.load(fis);
		}catch(IOException e) {
			
			System.out.println(e.getMessage());
		}
		
		
	}
		
	
	@BeforeMethod
	public void initDriver() {
		String browsername = prop.getProperty("browser");
		
		if (browsername.equals("chrome")) {
			
			System.setProperty("webdriver.chrome.driver","./resources/drivers/chromedriver.exe");
			driver = new ChromeDriver();
			logger.info("Chrome browser opened...");
		}
		
		else if (browsername.equals("firefox")){
			
			System.setProperty("webdriver.gecko.driver", "./resources/drivers/geckodriver.exe");
			driver  = new FirefoxDriver();
			logger.info("Firefox browser opened...");
		}
		
		else
			logger.info("Browser not present...");
	}
	
	@BeforeMethod
	public void openBrowser() {
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Integer.parseInt(prop.getProperty("globalWait")), TimeUnit.SECONDS);
		driver.get(prop.getProperty("url"));
		
		logger.info(prop.getProperty("url")+" page opened...");
	}
	

	
	@AfterMethod
	public void closeBrowser() {
		
		driver.quit();
		logger.info("Browser closed...");
	}
	
	
}
