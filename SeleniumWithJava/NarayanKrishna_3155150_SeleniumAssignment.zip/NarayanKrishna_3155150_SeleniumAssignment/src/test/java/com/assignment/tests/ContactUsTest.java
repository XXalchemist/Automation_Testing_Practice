package com.assignment.tests;


import org.testng.Assert;
import org.testng.annotations.Test;

import com.assignment.pages.ContactUsPage;




public class ContactUsTest extends BaseTest{
	
	// Test cases - check for valid and invalid logic for sending query
	
	@Test(priority = 1)
	public void testID_C1() {
		
		logger.info("testID_C1 Started");
		ContactUsPage contactPage = new ContactUsPage(driver);
		contactPage.clickContactUs();
		logger.info("Contact page opened...");
		
		contactPage.selectHeading(prop.getProperty("headingName1"));
		logger.info("Selection of heading...");
		
		contactPage.enterEmail(prop.getProperty("cEmail1"));
		logger.info("Email was entered...");
		
		contactPage.enterOrderId(prop.getProperty("orderReference1"));
		logger.info("OrderId was entered...");
		
		contactPage.enterMessage(prop.getProperty("cMessage1"));
		logger.info("Comment was entered...");
		
		contactPage.clickSend();
		logger.info("Comment is sent...");
		
		Assert.assertTrue(contactPage.getSuccessfulLink());
		logger.info("testID_C1 executed....Checked valid email, valid heading-selection, valid orderReferece1 and valid message");
	}
	
	@Test(priority = 2)
	public void testID_C2() {
		
		logger.info("testID_C2 started..");
		ContactUsPage contactPage = new ContactUsPage(driver);
		contactPage.clickContactUs();
		logger.info("Contact page opened...");
		
		contactPage.selectHeading(prop.getProperty("headingName2"));
		logger.info("Selection of heading...");
		
		contactPage.enterEmail(prop.getProperty("cEmail2"));
		logger.info("Email was entered...");
		
		contactPage.enterOrderId(prop.getProperty("orderReference2"));
		logger.info("OrderId was entered...");
		
		contactPage.enterMessage(prop.getProperty("cMessage2"));
		logger.info("Comment was entered...");
		
		contactPage.clickSend();
		logger.info("Comment is sent...");
		
		Assert.assertTrue(contactPage.getSuccessfulLink());
		logger.info("testID_C2 executed....Checked valid created user email, valid heading-selection, valid orderReferece1 and valid message");
		
	}
	@Test(priority = 3)
	public void testID_C3() {
		
		logger.info("testID_C3 started...");
		ContactUsPage contactPage = new ContactUsPage(driver);
		contactPage.clickContactUs();
		logger.info("Contact page opened...");
		
		contactPage.selectHeading(prop.getProperty("headingName3"));
		logger.info("Selection of heading...");
		
		contactPage.enterEmail(prop.getProperty("cEmail3"));
		logger.info("Email was entered...");
		
		contactPage.enterOrderId(prop.getProperty("orderReference3"));
		logger.info("OrderId was entered...");
		
		contactPage.enterMessage(prop.getProperty("cMessage3"));
		logger.info("Comment was entered...");
		
		contactPage.clickSend();
		logger.info("Comment is sent...");
		
		// log that it is negative test...and shall return 
		Assert.assertFalse(contactPage.getSuccessfulLink());
		
		logger.info("Negative test..testID_C3 executed....Checked Invalid email, valid heading-selection, valid orderReferece1 and valid message");
	}
}
