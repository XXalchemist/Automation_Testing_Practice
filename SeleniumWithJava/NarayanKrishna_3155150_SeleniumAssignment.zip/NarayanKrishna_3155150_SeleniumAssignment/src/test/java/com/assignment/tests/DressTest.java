package com.assignment.tests;

import com.assignment.utils.ExplicitWaitElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.assignment.pages.DressPage;

public class DressTest extends BaseTest{

	// Test cases for dress

	@Test
	// Check if selecting dress works or not
	public void testID_D1() {
		
		logger.info("testID_D1 started...");
		DressPage dressPage = new DressPage(driver);
		
		ExplicitWaitElement.checkClickableExplicitly(driver, dressPage.dress, Integer.parseInt(prop.getProperty("explicitWait")));
		
		dressPage.clickDress();
		logger.info("Dress section opened...");
		Assert.assertTrue(driver.getTitle().contains("Dress"));
		logger.info("testID_D1 executed...checked Dress button is working or not");
	}
	
	
}
