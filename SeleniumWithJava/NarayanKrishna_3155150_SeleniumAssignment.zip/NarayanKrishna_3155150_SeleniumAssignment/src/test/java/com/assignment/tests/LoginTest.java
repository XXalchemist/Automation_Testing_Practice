package com.assignment.tests;


import org.testng.Assert;
import org.testng.annotations.Test;

import com.assignment.pages.LoginPage;

public class LoginTest extends BaseTest{
	
	// To check different test cases
	
	@Test(priority = 1)
	public void testID_L1() {
		
		logger.info("testID_L1 started...");
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(prop.getProperty("email1"));
		logger.info("email was entered...");
		
		loginPage.enterPassword(prop.getProperty("pass1"));
		logger.info("password was entered...");
		
		loginPage.clickLogin();
		logger.info("login was clicked...");
		
		Assert.assertTrue(driver.getTitle().equals("My account - My Store"));
		logger.info("testID_L1 executed....checked valid registered email and valid password");
		
	}
	
	@Test(priority = 2)
	public void testID_L2() {
		
		logger.info("testID_L2 started...");
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(prop.getProperty("email2"));
		logger.info("email was entered...");
		
		loginPage.clickLogin();
		logger.info("password was entered...");
		
		Assert.assertTrue(driver.getTitle().equals("My account - My Store"));
		logger.info("testID_L2 executed....checked Invalid email");
	}
	
	@Test(priority = 3)
	public void testID_L3() {
		
		logger.info("testID_L3 started...");
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(prop.getProperty("email3"));
		logger.info("email was entered...");
		
		loginPage.enterPassword(prop.getProperty("pass3"));
		logger.info("password was entered...");
		
		loginPage.clickLogin();
		logger.info("login button was clicked...");
		
		Assert.assertFalse(driver.getTitle().equals("My account - My Store"));
		logger.info("testID_L3 executed....checked valid registered email and Invalid password");
	}
	
	@Test(priority = 4)
	public void testID_L4() {
		
		logger.info("testID_L4 started...");
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(prop.getProperty("email4"));
		logger.info("email was entered...");
		
		loginPage.enterPassword(prop.getProperty("pass4"));
		logger.info("password was entered....");
		
		loginPage.clickLogin();
		logger.info("login button was clicked....");
		
		Assert.assertFalse(driver.getTitle().equals("My account - My Store"));
		logger.info("testID_L4 executed....checked valid Not registered email and valid password");
	}
	

}
