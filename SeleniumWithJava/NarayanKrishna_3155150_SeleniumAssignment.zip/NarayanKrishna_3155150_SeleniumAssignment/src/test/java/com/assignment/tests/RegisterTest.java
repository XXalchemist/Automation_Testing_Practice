package com.assignment.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.assignment.pages.RegisterPage;
import com.assignment.utils.ExplicitWaitElement;

public class RegisterTest extends BaseTest {
	
	// To check registerPage take correct email or not 
	@Test(priority = 1)
	public void testID_R1()  {
		
		logger.info("testID_R1 was started...");
		RegisterPage registerPage = new RegisterPage(driver);
		
		registerPage.enterEmail(prop.getProperty("rEmail1"));
		logger.info("email was started...");
		
		registerPage.clickRegister();
		logger.info("clicked on create account button...");
		
		Assert.assertTrue(driver.getTitle().equals("Login - My Store"));
		logger.info("testID_R1 executed...checked valid email on register first page");
		
		
	}
	
	@Test(priority = 2)
	public void testID_R2() {
		
		logger.info("testID_R2 was started...");
		RegisterPage registerPage = new RegisterPage(driver);
		
		registerPage.enterEmail(prop.getProperty("rEmail2"));
		logger.info("email was entered...");
		
		registerPage.clickRegister();
		logger.info("clicked on create account button");
		
		Assert.assertTrue(driver.getTitle().equals("Login - My Store"));
		logger.info("testID_R2 executed...checked Invalid email on register second page");
	}
	
	
	@Test(priority = 3)
	public void testID_R3() {
		
		logger.info("testID_R3 was started....");
		RegisterPage registerPage = new RegisterPage(driver);
		
		registerPage.enterEmail(prop.getProperty("rEmailNew"));
		logger.info("email was entered...");
		
		registerPage.clickRegister();
		logger.info("clicked on create account button...");
		
		registerPage.enterDetails(prop.getProperty("firstnameValid"), prop.getProperty("lastnameValid"), prop.getProperty("rPasswordNew"), prop.getProperty("rAddress"), prop.getProperty("rCity"), prop.getProperty("rMobile"), prop.getProperty("rAlias"), prop.getProperty("rPostalCode"));
		logger.info("Details were entered in the form...");
		
		registerPage.selectMenu(prop.getProperty("rState"));
		logger.info("Selection of country and state were done...");
		
		registerPage.createNewAccount();
		logger.info("Clicked on submit button...");
		
		Assert.assertFalse(driver.getTitle().equals("My account - My Store")); // assertFalse is used to show the function of assertFals
		logger.info("testID_R2 executed...checked new account creation...");
	}
	

}
