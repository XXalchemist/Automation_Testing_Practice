package com.assignment.tests;


import org.testng.Assert;
import org.testng.annotations.Test;

import com.assignment.pages.SearchSection;

public class SearchTest extends BaseTest {
	

	// Test Cases for Search
	@Test(priority = 1)
	public void testID_S1() {
		
		logger.info("testID_S1 was started...");
		SearchSection searchSection = new SearchSection(driver);
		
		searchSection.clickSearchBox();
		logger.info("SearchBox was clicked...");
		
		searchSection.enterSearchItem(prop.getProperty("searchItem1"));
		logger.info("Item name was entered in the searchbox...");
		
		searchSection.clickSearchBtn();
		logger.info("search button is clicked...");
		
		Assert.assertTrue(driver.getTitle().equals("Search - My Store"));
		logger.info("testID_S1 executed...checked search box takes valid input");
		
	}
	
	@Test(priority = 2)
	public void testID_S2() {
		
		logger.info("testID_S2 was started...");
		SearchSection searchSection = new SearchSection(driver);
		
		searchSection.clickSearchBox();
		logger.info("SearchBox was clicked...");
		
		searchSection.enterSearchItem(prop.getProperty("searchItem2"));
		logger.info("Item name was entered...");
		
		searchSection.clickSearchBtn();
		logger.info("search button is clicked...");
		
		Assert.assertTrue(driver.getTitle().equals("Search - My Store"));
		logger.info("testID_S2 executed...checked search box handles invalid input");
	}
}
