package com.assignment.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.assignment.pages.WomenSectionPage;

public class WomenSectionTest extends BaseTest {
	
	// Test cases
	
	@Test(priority = 1)
	public void testID_W1() {
		
		logger.info("testID_W1 was started....");
		WomenSectionPage womenSectionPage = new WomenSectionPage(driver);
		
		womenSectionPage.hoverOnWomen();
		logger.info("hover over women section was done...");
		
		womenSectionPage.clickFirstProduct();
		logger.info("first product was clicked...");
		
		String firstProductName = womenSectionPage.getNameOfProduct();
		womenSectionPage.searchProduct(firstProductName);
		logger.info("first product was searched and matched...");
		
		Assert.assertTrue(womenSectionPage.matchProduct(firstProductName));
		logger.info("testID_W1 executed....checked Hover on Woman > Tshirt > Get First Product > Search That Product > Compare both");
		
	}
	
	@Test(priority = 2)
	public void testID_W2() {
		
		logger.info("testID_W1 was started....");
		WomenSectionPage womenSectionPage = new WomenSectionPage(driver);
		
		womenSectionPage.hoverOnWomen();
		logger.info("hover over women section was done...");
		
		womenSectionPage.clickFirstProduct();
		String searchProductName = prop.getProperty("productName");
		logger.info("first product was clicked...");
		
		womenSectionPage.searchProduct(searchProductName);
		logger.info("differnt product was searched and matched...");
		
		Assert.assertTrue(womenSectionPage.matchProduct(searchProductName));
		logger.info("testID_W2 executed....checked Hover on Woman > Tshirt > Get First Product > Search That Product > Compare both");
	}

}
