package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class BaseTest {

	public static WebDriver driver;
	
	@BeforeMethod
	public static void intializeDriver() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\nandinibhargava\\Desktop\\Selenium\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@BeforeMethod
	public static void openBrowser() {

		driver.get("http://demo.guru99.com/test/newtours/");
	}
	
	@AfterMethod
	public static void closeBrowser() {
		driver.quit();
	}
	
}
