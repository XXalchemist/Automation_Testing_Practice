package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.LoginPage;

public class LoginTest extends BaseTest {

	@Test
	public void validLogin() throws InterruptedException {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterUsername("Nandini123");
		loginPage.enterPassword();
		loginPage.clickSubmit();
		Thread.sleep(5000);
		// Assert.assertEquals(driver.getTitle(), "Login:Merucry Tours");
		Assert.assertTrue(driver.getTitle().contains("Login"));
	}

	@Test
	public void invalidLoginUsername() throws InterruptedException {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterUsername("Nandini1232343543");
		loginPage.enterPassword();
		loginPage.clickSubmit();
		Thread.sleep(5000);
		Assert.assertTrue(driver.getTitle().contains("Welcome"));
	}

}
