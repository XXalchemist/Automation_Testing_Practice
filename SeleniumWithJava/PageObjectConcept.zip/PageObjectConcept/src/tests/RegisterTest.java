package tests;

public class RegisterTest extends BaseTest {

	
	
	
}
