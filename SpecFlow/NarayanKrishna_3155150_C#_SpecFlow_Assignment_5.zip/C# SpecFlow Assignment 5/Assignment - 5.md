# C# SpecFlow Assignment-5

*Name :* NarayanKrishna

*Emp Id :* 3155150 

*Submission Date :* 14/12/2020 Before Midnight

### How to Run :-

1. Unzip Project
2. Open VisualStudio
3. Select open -> project/solutions -> StudentDatabase.sln
4. Select clean solution and then build solution from Build menu
5. Open Test Explorer and click on Run All

### This Project *(StudentDatabase)* contains :-

- 1 Class Library - *StudentsManager*
- 1 Nunit Test Package - *Test*

### _StudentsManager_ is used to perform Following operations :- 

- ADD Student
- CLEAR ALL Student Record
- GETBYID of Student

### _Test_ is used to perform BDD test with the help of SpecFlow 

It includes two features files (ADD Student and GET Student) and multiple step definitions files to check the working of StundentsManager Class library.

**In console after every scenario Students Database is shown for reference.**

> Important Topics covered :-

- Context Injection (with the help of Poco Class)
- Poco Class (Class containing only data variables)
- SpecFlow
- Nunit
- Hooks (Before and After)
- Enum
- Basics of oops
