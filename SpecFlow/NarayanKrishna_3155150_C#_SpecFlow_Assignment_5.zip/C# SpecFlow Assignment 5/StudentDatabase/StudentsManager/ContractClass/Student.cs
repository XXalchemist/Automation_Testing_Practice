﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentsManager
{
    // Contract class - used tho have data members id, name, age, branch, section
    public class Student
    {
        // Data members - internal is used to set and get value 
        private int id;
        public string name;
        public int age;
        public int branch;
        public int section;

        // id - can be access from anywhere but can be set only in same assembly

        // id can be access from anywhere
        public int GetId()
        {
            return id;
        }

        // id can be set only in same assembly i.e class library
        internal void SetId(int value)
        {
            id = value;
        }
    }
}
