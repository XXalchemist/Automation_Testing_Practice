﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentsManager.Main
{
    public class Students
    {
        // this is used to store student data with respect to their unique id as key in dictionary
        public static Dictionary<string, Student> studentsData = new Dictionary<string, Student>();
        private static int idCount;

        // To add student through student data and return id of that student
        public static int Add(Student student)
        {
            // increment id by 1 for each Student data creation
            idCount += 1;

            // key for the record
            string keyName = student.name.ToLower(); 

            // New instance of student is created for each student
            Student newStudent = new Student();

            // To validate given name
            if (!ValidateName(student.name))
                throw new Exception("Student record with same name already exists");
           

            // setting up the values
            newStudent.name = student.name;
            newStudent.age = student.age;
            newStudent.SetId(idCount);

            // setting up the enum data variables - add later
            newStudent.branch = student.branch;
            newStudent.section = student.section;

            // Adding the new student to the student record
            studentsData.Add(keyName, newStudent);

            return idCount;
        }

        // returns student data through given Id
        public static Student GetById(int GivenId)
        {
            foreach(var studentRecord in studentsData) {

                if (GivenId == studentRecord.Value.GetId())
                    return studentRecord.Value;

            }
          
            throw new Exception("No record found");
        }

        // method to delete all student data from student record
        public static void ClearAll()
        {
             studentsData.Clear();
                
             // id should be reset to zero
             idCount = 0;

            //Can be used to debug

            /* foreach (var studentRecord in studentsData)
                {
                Console.WriteLine(studentRecord.Value.name);
                }
            */
        }






        // Method to validate given name with the data in record
        private static bool ValidateName(string GivenName)
        {
            foreach (var studentRecord in studentsData)
                if (GivenName.Equals(studentRecord.Value.name))
                    return false;

            return true;
        }
    }
}
