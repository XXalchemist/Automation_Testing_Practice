﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentsManager.enumFiles
{   
   
    public class BranchEnum
    {
        public enum Branch
        {
            CS = 101,
            IT = 102,
            ECE = 103,
            ME = 104,
            EE = 105,
            EI = 106,
            CIVIL = 107,
            CHEM = 108,
            ENV = 109
        }
    }
   
}
