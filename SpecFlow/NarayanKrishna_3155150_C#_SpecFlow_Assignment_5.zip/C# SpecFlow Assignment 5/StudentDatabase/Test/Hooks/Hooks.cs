﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using StudentsManager.Main;

namespace Test.Hooks
{
    [Binding]
    public sealed class Hooks
    {


        [BeforeScenario]
        public void BeforeScenario()
        {
            // call ClearAll method before each individual test
            Students.ClearAll();
            Console.WriteLine("All data deleted....");
        }

        [AfterScenario]
        public void AfterScenario()
        {
            Console.WriteLine("Test case successfully executed...");
            Console.WriteLine("--------------------");
            Console.WriteLine("Students Database :-");
            Console.WriteLine("---------------------\n");
            foreach (var studentRecord in Students.studentsData)
            {
                Console.WriteLine($"Id : {studentRecord.Value.GetId()} - Name : {studentRecord.Value.name} - Branch :{studentRecord.Value.branch} - Section : {studentRecord.Value.section} - Age : {studentRecord.Value.age}");
            }
        }
    }
}
