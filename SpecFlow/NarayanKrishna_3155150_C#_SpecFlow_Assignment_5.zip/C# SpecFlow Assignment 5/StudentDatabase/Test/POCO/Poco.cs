﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.POCO
{
    public class Output
    {

        // have two data members - object, string
        private object result;
        private string errorMessage;

        // result will store returned data from add/get by id method
        public object Result { get => result; set => result = value; }

        // will store error message throws from add/get by id method
        public string ErrorMessage { get => errorMessage; set => errorMessage = value; }

    }
}
