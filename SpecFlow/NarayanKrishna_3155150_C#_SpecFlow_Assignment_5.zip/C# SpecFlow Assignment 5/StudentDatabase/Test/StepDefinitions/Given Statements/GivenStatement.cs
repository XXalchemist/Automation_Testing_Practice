﻿using StudentsManager;
using StudentsManager.Main;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using Test.POCO;
using static StudentsManager.enumFiles.BranchEnum;
using static StudentsManager.enumFiles.SectionEnum;



namespace Test.StepDefinitions.Given_Statements
{
    [Binding]
    public sealed class GivenStatement
    {
      
        private readonly Output output;

        // data variables required to store converted enum string
        private Branch enumBranch;
        private Section enumSection;


        public GivenStatement(Output output)
        {

            this.output = output;
        }

        // Creating an instance of students to perform following operations
        //Students students = new Students();

        // Given for Add Record
        [Given(@"Database already have student (.*), (.*), (.*), (.*) with ID - (.*)")]
        public void GivenDatabaseAlreadyHaveStudentNarayanCSEBWithID_(string givenName, int givenAge, string givenBranch, string givenSection, int givenId)
        {
            // new student with the given data created
            Student newStudent = new Student();
            newStudent.name = givenName;
            newStudent.age = givenAge;

            // Enum.Parse(Branch, givenBranch) use to convert string into respective enum
            enumBranch = (Branch)Enum.Parse(typeof(Branch), givenBranch);
            enumSection = (Section)Enum.Parse(typeof(Section), givenSection);

            // use of enum in branch and section
            newStudent.branch = (int)enumBranch;
            newStudent.section = (int)enumSection;

            // For storing result in Result which will be not neccessary for given statement as it is pre requirement
            // Storing of students is only neccessary
            try
            {
                output.Result = Students.Add(newStudent);
            }
            catch(Exception e)
            {
                output.ErrorMessage = e.Message;
            }
           
               
        }


    }
}
