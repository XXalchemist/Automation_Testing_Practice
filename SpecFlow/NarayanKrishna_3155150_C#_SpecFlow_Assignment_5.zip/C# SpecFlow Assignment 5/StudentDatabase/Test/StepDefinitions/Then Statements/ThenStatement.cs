﻿using NUnit.Framework;
using StudentsManager;
using StudentsManager.Main;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using Test.POCO;

namespace Test.StepDefinitions.Then_Statements
{
    [Binding]
    public sealed class ThenStatement
    {

        private readonly Output output;

        public ThenStatement(Output output)
        {
            this.output = output;
        }
        
        // Then for Add Student

        [Then(@"Student data is added to the record")]
        public void ThenStudentDataIsAddedToTheRecord()
        {

            // actual output - get data from class library 
            // expected output - id is 2 as 2 records were stored
            Assert.AreEqual(2, output.Result);
        }

        [Then(@"Exception is thrown that (.*)")]
        public void ThenExceptionIsThrownThatDuplicateDataExist(string expectedResult)
        {
            // define in feature
            Assert.AreEqual(expectedResult, output.ErrorMessage);
        }

        // Then Statement for Get Student
        [Then(@"I get the record for ID - (.*) student")]
        public void ThenIGetTheRecordForID_Student(int GivenId)
        {
            Student oldStudent = new Student();

            oldStudent = Students.GetById(GivenId);

            // (expected, actual)
            Assert.AreEqual(GivenId, oldStudent.GetId());
        }

        [Then(@"I get the Exception of (.*)")]
        public void ThenIGetTheExceptionOfInvalidId_(string expectedResult)
        {
            // Actual output is from poco class and expected output is from feature file
            Assert.AreEqual(expectedResult, output.ErrorMessage);
        }

    }
}
