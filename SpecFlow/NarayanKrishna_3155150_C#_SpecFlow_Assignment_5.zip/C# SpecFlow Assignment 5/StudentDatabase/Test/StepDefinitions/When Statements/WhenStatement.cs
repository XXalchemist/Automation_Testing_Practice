﻿using StudentsManager;
using StudentsManager.enumFiles;
using StudentsManager.Main;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using Test.POCO;
using static StudentsManager.enumFiles.BranchEnum;
using static StudentsManager.enumFiles.SectionEnum;

namespace Test.StepDefinitions.When_Statements
{
    [Binding]
    public sealed class WhenStatement
    {
      
       
        private readonly Output output;

        // Data variables for enum
        private Branch enumBranch;
        private Section enumSection;

        //private Dictionary<string, Student> students;

        public WhenStatement(Output output)
        {
            this.output = output;
        }

        // When for Add student
        [When(@"Add new student with given details (.*), (.*), (.*), (.*)")]
        public void WhenAddNewStudentWithGivenDetailsNarayanCSEB(string givenName, int givenAge, string givenBranch, string givenSection)
        {
            // accesing students record from scenario context
            //students = _studentsData["StudentsRecord"];


            // creating new student
            Student newStudent = new Student();
            newStudent.name = givenName;
            newStudent.age = givenAge;

            // Enum.Parse(Branch, givenBranch) use to convert string into respective enum
            enumBranch = (Branch) Enum.Parse(typeof(Branch), givenBranch);
            enumSection = (Section) Enum.Parse(typeof(Section), givenSection);

            // use of enum in branch and section
            newStudent.branch = (int)enumBranch;
            newStudent.section = (int)enumSection;

            // For storing result in Result if 
            try
            {
                output.Result = Students.Add(newStudent);
                //_studentsData.Add("StudentAddResult", result);
            }
            catch (Exception e)
            {
                output.ErrorMessage = e.Message;
                //_studentsData.Add("StudentAddError", errorMessage);
            }


        }

        // When for Get Student
        [When(@"I searched student by entering (.*)")]
        public void WhenISearchedStudentByEntering(int GivenId)
        {
            try
            {
                output.Result = Students.GetById(GivenId);
            }
            catch(Exception e)
            {
                output.ErrorMessage = e.Message;
            }
        }

    }
}
